/* Bubbles 2048: rendering and input are intentionally plain Canvas 2D. */
(() => {
  'use strict';

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const status = document.getElementById('status');
  const SAVE_KEY = 'bubbles2048_canvas_v1';
  const BOARD = { x: 176, y: 84, w: 448, h: 636 };
  const WORLD_SCALE = BOARD.w / 500;
  const MAX_DT = 1 / 30;
  const BALL_ART_FILL = 0.985;
  const START_COINS = 0;
  const prices = { swap: 50, shake: 10, hammer: 50 };
  const audioFiles = {
    click: 'ui-click.m4a', hover: 'ui-hover.m4a', coin: 'coin-fill.m4a',
    merge: 'success-pop.m4a', goal: 'star-bright.m4a', notification: 'notification.m4a'
  };
  const uiFiles = ['background', 'tutorial', 'settings', 'swap', 'shake', 'hammer', 'crown', 'coin', 'close', 'sound-on', 'sound-off'];
  const ballNames = ['2','4','8','16','32','64','128','256','512','1024','2048','4096','8192','16k','32k','64k','128k','256k','512k','1M','2M','4M','8M','16M','32M','64M','128M','256M','512M','1B'];
  const images = {};
  const audioClips = {};
  let spriteProbeCanvas = null;
  let spriteProbeContext = null;
  for (const name of uiFiles) loadImage(name, `./assets/ui/${name}.png`);
  for (const name of ballNames) loadImage(`ball-${name}`, `./assets/balls/${name}.png`);
  let width = 0, height = 0, scale = 1, originX = 0, originY = 0;
  let modal = null;
  let mode = null;
  let selectedId = null;
  let hoveredId = null;
  let coins = START_COINS;
  let best = 0;
  let goal = 1024;
  let sound = true;
  let hoveredButtonLabel = null;
  let buttons = [];
  let toast = null;
  let lastTime = 0;
  let saveTimer = 0;
  let audioContext = null;
  let animation = [];
  let mergeAnimation = null;
  let clickFlash = null;
  let physics;

  function measureBallSprite(img) {
    try {
      if (!spriteProbeCanvas) {
        spriteProbeCanvas = document.createElement('canvas');
        spriteProbeContext = spriteProbeCanvas.getContext('2d', { willReadFrequently: true });
      }
      const w = img.naturalWidth, h = img.naturalHeight;
      spriteProbeCanvas.width = w; spriteProbeCanvas.height = h;
      spriteProbeContext.clearRect(0, 0, w, h);
      spriteProbeContext.drawImage(img, 0, 0);
      const pixels = spriteProbeContext.getImageData(0, 0, w, h).data;
      let widest = 0, centerXSum = 0, centerYSum = 0, bandCount = 0;
      for (let y = 0; y < h; y++) {
        let left = w, right = -1;
        for (let x = 0; x < w; x++) {
          if (pixels[(y * w + x) * 4 + 3] > 8) { left = Math.min(left, x); right = x; }
        }
        const span = right - left + 1;
        if (span <= 0) continue;
        if (span > widest) { widest = span; centerXSum = centerYSum = bandCount = 0; }
        if (span === widest) {
          centerXSum += (left + right + 1) / 2;
          centerYSum += y;
          bandCount++;
        }
      }
      if (!widest || !bandCount) return null;
      const centerY = centerYSum / bandCount;
      // One high-value ornament has a decorative sprig away from the equator.
      return {
        width: widest,
        centerX: centerXSum / bandCount,
        centerY: Math.abs(centerY - h / 2) > h * 0.12 ? h / 2 : centerY
      };
    } catch (_) {
      // Keep a conservative draw fallback if pixel inspection is restricted.
      return null;
    }
  }

  function loadImage(name, src) {
    const img = new Image();
    if (name.startsWith('ball-')) img.onload = () => { img.ballGeometry = measureBallSprite(img); };
    img.src = src;
    images[name] = img;
  }
  function validImage(img) { return img && img.complete && img.naturalWidth > 0; }
  function image(name, x, y, w, h) {
    const img = images[name];
    if (validImage(img)) ctx.drawImage(img, x, y, w, h);
  }
  function coloredIcon(name, x, y, size, color) {
    const source = images[name];
    if (!validImage(source)) return;
    const key = `${name}:${color}`;
    if (!coloredIcon.cache[key]) {
      const temp = document.createElement('canvas');
      temp.width = source.naturalWidth; temp.height = source.naturalHeight;
      const c = temp.getContext('2d');
      c.drawImage(source, 0, 0);
      c.globalCompositeOperation = 'source-in';
      c.fillStyle = color; c.fillRect(0, 0, temp.width, temp.height);
      coloredIcon.cache[key] = temp;
    }
    const img = coloredIcon.cache[key];
    const ratio = img.width / img.height;
    ctx.drawImage(img, x + (size - size * ratio) / 2, y, size * ratio, size);
  }
  coloredIcon.cache = {};

  function rounded(x, y, w, h, r, fill, stroke, lineWidth = 1) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lineWidth; ctx.stroke(); }
  }
  function text(str, x, y, size, color = '#f7fbff', align = 'center', stroke = null, lineWidth = 3) {
    ctx.font = `${size}px Kardinal, system-ui, sans-serif`;
    ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    if (stroke) { ctx.lineWidth = lineWidth; ctx.strokeStyle = stroke; ctx.strokeText(String(str), x, y); }
    ctx.fillStyle = color; ctx.fillText(String(str), x, y);
  }
  function register(x, y, w, h, action, label) { buttons.push({ x, y, w, h, action, label }); }
  function drawButton(x, y, w, h, label, action, options = {}) {
    const color = options.color || '#27d1e6';
    rounded(x, y + 4, w, h, 9, options.shadow || '#087b91');
    rounded(x, y, w, h, 9, color, options.border || null, 2);
    if (label) text(label, x + w / 2, y + h / 2 + 1, options.size || 27, options.textColor || '#0872a0');
    register(x, y, w, h, action, label);
  }
  function showToast(message, duration = 2.5) {
    toast = { message, left: duration };
    status.textContent = message;
  }
  function playTone(freq = 550, duration = .11) {
    if (!sound) return;
    try {
      audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
      if (audioContext.state === 'suspended') audioContext.resume();
      const osc = audioContext.createOscillator(); const gain = audioContext.createGain();
      osc.type = 'sine'; osc.frequency.setValueAtTime(freq, audioContext.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.4, audioContext.currentTime + duration);
      gain.gain.setValueAtTime(.055, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + duration);
      osc.connect(gain); gain.connect(audioContext.destination); osc.start(); osc.stop(audioContext.currentTime + duration);
    } catch (_) { /* audio is optional */ }
  }
  function playSound(name, fallbackFreq = 550, fallbackDuration = .11) {
    if (!sound) return;
    try {
      const file = audioFiles[name];
      if (!file) { playTone(fallbackFreq, fallbackDuration); return; }
      const clip = audioClips[name] || (audioClips[name] = new Audio(`./assets/audio/${file}`));
      clip.preload = 'auto';
      clip.volume = .58;
      clip.currentTime = 0;
      const playback = clip.play();
      if (playback && typeof playback.catch === 'function') {
        playback.catch(() => playTone(fallbackFreq, fallbackDuration));
      }
    } catch (_) { playTone(fallbackFreq, fallbackDuration); }
  }
  function onMerge(event) {
    playSound('merge', 470 + Math.min(600, Math.log2(event.value) * 40));
    best = Math.max(best, physics.score);
    const x = BOARD.x + event.ball.x * WORLD_SCALE;
    const y = BOARD.y + event.ball.y * WORLD_SCALE;
    // Данные физики уже обновлены; сохраняем отдельные снимки для плавного перехода.
    mergeAnimation = {
      age: 0, duration: .52,
      sources: event.sources,
      target: { id: event.ball.id, x: event.ball.x, y: event.ball.y, r: event.ball.r, value: event.value,
        angle: event.ball.angle || 0, angularVelocity: event.ball.angularVelocity || 0 },
      scoreEffect: { x, y, age: 0, text: `+${event.scoreAdded}`, value: event.value },
      reachedGoal: null
    };
    hoveredId = null;
    if (event.count >= 6) showToast(`Отличное комбо x${event.count}!`);
    if (event.value >= goal) {
      const reached = goal;
      coins += 50;
      while (goal <= event.value) goal *= 2;
      // Не закрываем само слияние окном награды — покажем его после анимации.
      mergeAnimation.reachedGoal = reached;
    }
    persist();
  }
  function onNoMoves() {
    playSound('notification', 360, .16);
    if (!modal) modal = { type: 'noMoves' };
  }
  function followMergeTarget() {
    if (!mergeAnimation) return;
    const liveBall = physics.balls.find(ball => ball.id === mergeAnimation.target.id);
    if (!liveBall) return;
    // Визуальная оболочка следует за реальным телом, пока остальные шары
    // продолжают падать и сталкиваться в фоне.
    mergeAnimation.target.x = liveBall.x;
    mergeAnimation.target.y = liveBall.y;
    mergeAnimation.target.r = liveBall.r;
    mergeAnimation.target.angle = liveBall.angle;
    mergeAnimation.target.angularVelocity = liveBall.angularVelocity;
  }
  physics = new BubblePhysics({ onMerge, onNoMoves });

  function persist() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        version: 1, physics: physics.serialize(), best, coins, goal, sound, tutorialSeen: true
      }));
    } catch (_) { /* game remains playable when storage is unavailable */ }
  }
  function restore() {
    try {
      const data = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null');
      if (!data || data.version !== 1 || !data.physics || !physics.load(data.physics)) return false;
      best = Number.isFinite(data.best) ? Math.max(0, data.best) : 0;
      coins = Number.isFinite(data.coins) ? Math.max(0, Math.floor(data.coins)) : START_COINS;
      goal = Number.isFinite(data.goal) ? Math.max(1024, data.goal) : 1024;
      sound = data.sound !== false;
      return true;
    } catch (_) { return false; }
  }
  function newGame(showIntro = false) {
    physics.reset();
    mode = null; selectedId = null; animation = []; mergeAnimation = null; goal = 1024;
    modal = showIntro ? { type: 'tutorial' } : null;
    if (!showIntro) persist();
    showToast('Найдите одинаковые шарики', 2.1);
  }
  const restored = restore();
  if (!restored) newGame(true);
  else if (physics.state === 'no-moves') modal = { type: 'noMoves' };

  function resize() {
    width = canvas.clientWidth; height = canvas.clientHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
    scale = Math.min(height / 800, width / 448);
    originX = (width - 800 * scale) / 2;
    originY = (height - 800 * scale) / 2;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener('resize', resize);
  resize();

  function drawBackground() {
    ctx.fillStyle = '#06121d'; ctx.fillRect(0, 0, width, height);
    const bg = images.background;
    if (validImage(bg)) {
      // The original uses a square winter illustration centered on the playing area.
      const side = Math.max(height, width < height ? height : 0);
      const x = (width - side) / 2;
      ctx.drawImage(bg, x, 0, side, height);
    } else {
      const gradient = ctx.createLinearGradient(0, 0, 0, height);
      gradient.addColorStop(0, '#133d5b'); gradient.addColorStop(1, '#081521');
      ctx.fillStyle = gradient; ctx.fillRect(0, 0, width, height);
    }
  }
  function ballName(value) {
    const idx = Math.max(0, Math.min(ballNames.length - 1, Math.round(Math.log2(value)) - 1));
    return ballNames[idx];
  }
  function formatValue(value) {
    if (value >= 1e9) return `${Math.round(value / (1024 ** 3))}B`;
    if (value >= 1024 ** 2) return `${Math.round(value / (1024 ** 2))}M`;
    if (value >= 10000) return `${Math.round(value / 1024)}k`;
    return String(value);
  }
  function drawBall(ball) {
    const x = BOARD.x + ball.x * WORLD_SCALE;
    const y = BOARD.y + ball.y * WORLD_SCALE;
    const r = ball.r * WORLD_SCALE;
    const sprite = images[`ball-${ballName(ball.value)}`];
    if (ball.id === selectedId) {
      ctx.save(); ctx.shadowColor = '#54faff'; ctx.shadowBlur = 18;
      ctx.beginPath(); ctx.arc(x, y, r + 5, 0, Math.PI * 2); ctx.lineWidth = 4; ctx.strokeStyle = '#a7ffff'; ctx.stroke(); ctx.restore();
    } else if (ball.id === hoveredId && !modal) {
      ctx.save(); ctx.globalAlpha = .45; ctx.beginPath(); ctx.arc(x, y, r + 3, 0, Math.PI * 2); ctx.lineWidth = 2; ctx.strokeStyle = '#ffffff'; ctx.stroke(); ctx.restore();
    }
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ball.angle || 0);
    if (validImage(sprite)) {
      // PNGs have different transparent margins and some carry a raised cap.
      // Fit the widest opaque row to the physical circle and align its center.
      const geometry = sprite.ballGeometry;
      const spriteScale = geometry ? (2 * r * BALL_ART_FILL) / geometry.width : (2 * r * 0.95) / sprite.naturalWidth;
      const centerX = geometry ? geometry.centerX : sprite.naturalWidth / 2;
      const centerY = geometry ? geometry.centerY : sprite.naturalHeight * 0.54;
      ctx.drawImage(sprite, -centerX * spriteScale, -centerY * spriteScale,
        sprite.naturalWidth * spriteScale, sprite.naturalHeight * spriteScale);
    } else {
      ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2);
      const colors = ['#e9ebee','#00c4cd','#c99a08','#d30d1b','#18a75b','#be12bd'];
      const gradient = ctx.createRadialGradient(-r / 3, -r / 3, 2, 0, 0, r);
      gradient.addColorStop(0, '#ffffff'); gradient.addColorStop(.22, colors[Math.max(0, Math.log2(ball.value) - 1) % colors.length]); gradient.addColorStop(1, '#0a2734');
      ctx.fillStyle = gradient; ctx.fill();
    }
    ctx.restore();
    const value = formatValue(ball.value);
    const fontSize = Math.min(r * .93, (r * 1.65) / Math.max(1, value.length * .55));
    text(value, x, y + 2, fontSize, '#fff348', 'center', '#251b05', Math.max(2.8, r * .12));
  }
  function drawMergeAnimation() {
    if (!mergeAnimation) return;
    const { sources, target, age, duration } = mergeAnimation;
    const progress = Math.min(1, age / duration);
    const travel = Math.min(1, progress / .64);
    const eased = 1 - (1 - travel) ** 3;
    const oldAlpha = Math.max(0, Math.min(1, (0.69 - progress) / .15));

    // Все одинаковые шары прилетают к тому, по которому нажал игрок.
    ctx.save();
    ctx.globalAlpha = oldAlpha;
    for (const source of sources) {
      const selected = source.id === target.id;
      drawBall({
        id: -1, value: source.value,
        x: source.x + (target.x - source.x) * eased,
        y: source.y + (target.y - source.y) * eased,
        r: source.r * (selected ? 1 - .22 * eased : 1 - .48 * eased),
        angle: (source.angle || 0) + (source.angularVelocity || 0) * age
      });
    }
    ctx.restore();

    if (progress >= .52) {
      const pop = Math.min(1, (progress - .52) / .48);
      // Лёгкий overshoot создаёт узнаваемое упругое появление нового шарика.
      const q = pop - 1;
      const popScale = Math.max(.05, 1 + 2.70158 * q ** 3 + 1.70158 * q ** 2);
      ctx.save();
      ctx.globalAlpha = Math.min(1, pop * 5);
      drawBall({ ...target, id: -1, r: target.r * popScale });
      ctx.restore();

      // Короткое сияние в момент соединения, без влияния на физику шаров.
      const sparkle = Math.max(0, 1 - pop);
      const x = BOARD.x + target.x * WORLD_SCALE;
      const y = BOARD.y + target.y * WORLD_SCALE;
      const radius = target.r * WORLD_SCALE * (.8 + pop * .8);
      ctx.save();
      ctx.globalAlpha = sparkle * .8;
      ctx.lineWidth = 2 + 2 * sparkle;
      ctx.strokeStyle = '#fff3ad';
      ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2); ctx.stroke();
      for (let i = 0; i < 8; i++) {
        const angle = i * Math.PI / 4;
        const sx = x + Math.cos(angle) * radius * 1.18;
        const sy = y + Math.sin(angle) * radius * 1.18;
        ctx.fillStyle = i % 2 ? '#8af5ff' : '#fff5b4';
        ctx.beginPath(); ctx.arc(sx, sy, 2.5 + sparkle * 1.6, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
    }
  }
  function drawTop() {
    rounded(BOARD.x - 2, -2, BOARD.w + 4, 87, 6, '#25354f');
    rounded(BOARD.x + 2, 0, 143, 41, 5, '#192a41');
    rounded(BOARD.x + 2, 44, 143, 37, 5, '#192a41');
    rounded(BOARD.x + 150, 0, BOARD.w - 154, 81, 5, '#192a41');
    image('crown', BOARD.x + 10, 9, 27, 25);
    text(best, BOARD.x + 44, 22, 24, '#f7fbff', 'left');
    image('coin', BOARD.x + 10, 49, 27, 28);
    text(coins, BOARD.x + 44, 63, 22, '#f7fbff', 'left');
    rounded(BOARD.x + 116, 50, 25, 25, 6, '#2a3c55');
    text('+', BOARD.x + 128.5, 63, 23, '#0d1e30');
    register(BOARD.x + 112, 46, 33, 33, () => { modal = { type: 'bank' }; }, 'Монеты');
    text(physics.score, BOARD.x + 150 + (BOARD.w - 154) / 2, 44, 38);
  }
  function drawTool(x, w, icon, price, action, selected) {
    rounded(x, 727, w, 67, 9, '#137d68');
    rounded(x + 2, 727, w - 4, 61, 8, selected ? '#76f9b2' : '#26e989');
    rounded(x + 8, 732, 41, 49, 6, '#72f5ab');
    coloredIcon(icon, x + 13, 739, 30, '#007d6d');
    image('coin', x + 58, 740, 26, 27);
    text(price, x + w - 13, 755, 22, '#008b74', 'right');
    register(x, 727, w, 67, action, icon);
  }
  function drawBottom() {
    rounded(BOARD.x - 2, 722, BOARD.w + 4, 78, 9, '#1b2d46');
    rounded(BOARD.x + 3, 728, 47, 62, 7, '#139cb7');
    rounded(BOARD.x + 3, 728, 47, 55, 7, '#35d1e8');
    coloredIcon('settings', BOARD.x + 11, 738, 31, '#0878a6');
    register(BOARD.x + 2, 728, 48, 63, () => { mode = null; modal = { type: 'settings' }; }, 'Настройки');
    drawTool(BOARD.x + 55, 126, 'swap', prices.swap, () => activateTool('swap'), mode === 'swap');
    drawTool(BOARD.x + 185, 126, 'shake', prices.shake, () => activateTool('shake'), mode === 'shake');
    drawTool(BOARD.x + 315, 130, 'hammer', prices.hammer, () => activateTool('hammer'), mode === 'hammer');
  }
  function drawBoard() {
    ctx.save();
    ctx.beginPath(); ctx.rect(BOARD.x, BOARD.y, BOARD.w, BOARD.h); ctx.clip();
    ctx.fillStyle = 'rgba(5, 12, 21, .79)'; ctx.fillRect(BOARD.x, BOARD.y, BOARD.w, BOARD.h);
    for (const ball of physics.balls) {
      if (!mergeAnimation || ball.id !== mergeAnimation.target.id) drawBall(ball);
    }
    drawMergeAnimation();
    for (const item of animation) {
      const alpha = Math.max(0, 1 - item.age / 1.1);
      ctx.globalAlpha = alpha;
      text(item.text, item.x, item.y - item.age * 55, 25, '#fff68a', 'center', '#543a16', 3);
      ctx.globalAlpha = 1;
    }
    if (mode) {
      rounded(BOARD.x + 20, BOARD.y + 11, BOARD.w - 40, 37, 10, 'rgba(20,45,62,.94)');
      text(mode === 'swap' ? (selectedId === null ? 'Выберите первый шарик' : 'Выберите второй шарик') : 'Выберите шарик, который нужно убрать', BOARD.x + BOARD.w / 2, BOARD.y + 29, 18, '#d9ffff');
    }
    ctx.restore();
  }
  function drawToast() {
    if (!toast || toast.left <= 0 || modal) return;
    const alpha = Math.min(1, toast.left * 2);
    ctx.save(); ctx.globalAlpha = alpha;
    rounded(237, 99, 326, 37, 10, 'rgba(16,36,57,.88)');
    text(toast.message, 400, 118, 19, '#f2fbff');
    ctx.restore();
  }
  function drawDialogFrame(x, y, w, h, title) {
    ctx.fillStyle = 'rgba(0, 0, 0, .76)'; ctx.fillRect(-2000, -1000, 4800, 3000);
    rounded(x, y, w, h, 23, '#1f3352', '#2d4669', 4);
    rounded(x + 4, y + 4, w - 8, 52, 17, '#192b47');
    ctx.fillStyle = '#192b47'; ctx.fillRect(x + 4, y + 33, w - 8, 23);
    text(title, x + w / 2, y + 31, 32, '#62a5e8');
    rounded(x + w - 49, y + 9, 39, 39, 20, '#7c9ab8');
    coloredIcon('close', x + w - 43, y + 15, 27, '#263e5b');
    register(x + w - 51, y + 6, 45, 45, () => { modal = null; persist(); }, 'Закрыть');
  }
  function drawModal() {
    if (!modal) return;
    const type = modal.type;
    if (type === 'tutorial') {
      const x = 200, y = 163, w = 400, h = 480;
      drawDialogFrame(x, y, w, h, 'Как играть:');
      text('Просто нажимайте на шарики,', 400, y + 92, 26, '#e2eaf4');
      text('чтобы объединять их с такими', 400, y + 127, 26, '#e2eaf4');
      text('же шариками по соседству.', 400, y + 162, 26, '#e2eaf4');
      image('tutorial', 298, y + 185, 204, 210);
      drawButton(293, y + 412, 214, 49, 'Понятно!', () => { modal = { type: 'goal' }; }, { size: 29 });
    } else if (type === 'goal' || type === 'goalReached') {
      const x = 241, y = 254, w = 318, h = 291;
      drawDialogFrame(x, y, w, h, type === 'goal' ? 'Следующая цель' : 'Новая цель!');
      const val = type === 'goal' ? goal : modal.value;
      const sprite = images[`ball-${ballName(val)}`];
      if (validImage(sprite)) ctx.drawImage(sprite, 347, y + 84, 106, 112);
      text(formatValue(val), 400, y + 145, 34, '#fff246', 'center', '#261b05', 4);
      if (type === 'goalReached') text('+50 монет', 400, y + 210, 19, '#f9db67');
      drawButton(293, y + 225, 214, 47, type === 'goal' ? 'Начать!' : 'Получить!', () => { modal = null; persist(); }, { size: 27 });
    } else if (type === 'settings') {
      const x = 220, y = 223, w = 360, h = 355;
      drawDialogFrame(x, y, w, h, 'Настройки');
      drawButton(264, y + 83, 272, 46, sound ? 'Звук: вкл.' : 'Звук: выкл.', () => { sound = !sound; persist(); }, { size: 24 });
      drawButton(264, y + 151, 272, 46, 'Как играть', () => { modal = { type: 'tutorial' }; }, { size: 24 });
      drawButton(264, y + 219, 272, 46, 'Начать заново', () => { modal = { type: 'restart' }; }, { size: 24, color: '#3fdeb0', textColor: '#087a72', shadow: '#168b78' });
      text('Лучший результат: ' + best, 400, y + 308, 18, '#bccce0');
    } else if (type === 'restart') {
      drawDialogFrame(225, 273, 350, 240, 'Новая игра?');
      text('Текущий прогресс будет сброшен.', 400, 362, 20, '#e2eaf4');
      drawButton(253, 403, 137, 46, 'Отмена', () => { modal = { type: 'settings' }; }, { size: 23 });
      drawButton(410, 403, 137, 46, 'Начать', () => { newGame(false); }, { size: 23, color: '#3fdeb0', textColor: '#087a72', shadow: '#168b78' });
    } else if (type === 'bank' || type === 'notEnough') {
      drawDialogFrame(225, 258, 350, 278, type === 'bank' ? 'Нужны монеты?' : 'Недостаточно монет');
      text('Монеты нужны для усилений.', 400, 347, 20, '#e2eaf4');
      image('coin', 379, 374, 42, 44);
      text('+50', 400, 435, 24, '#ffe780');
      drawButton(270, 463, 260, 47, 'Получить бесплатно', () => { coins += 50; modal = null; persist(); playSound('coin', 760); showToast('Получено 50 монет!'); }, { size: 21 });
    } else if (type === 'noMoves') {
      drawDialogFrame(225, 265, 350, 260, 'Нет ходов');
      text('Продолжить?', 400, 361, 25, '#e2eaf4');
      drawButton(264, 405, 272, 46, 'Перемешать', () => { modal = null; physics.shake(); }, { size: 24 });
      drawButton(264, 465, 272, 42, 'Новая игра', () => { newGame(false); }, { size: 22, color: '#3fdeb0', textColor: '#087a72', shadow: '#168b78' });
    }
  }

  function activateTool(which) {
    if (mode === which) { mode = null; selectedId = null; return; }
    if (coins < prices[which]) { modal = { type: 'notEnough' }; return; }
    if (which === 'shake') {
      coins -= prices.shake; physics.shake(); mode = null; selectedId = null;
      showToast('Шарики перемешаны!'); persist();
    } else {
      mode = which; selectedId = null;
      showToast(which === 'swap' ? 'Выберите два шарика' : 'Выберите шарик', 2);
    }
  }
  function ballAt(x, y) {
    const worldX = (x - BOARD.x) / WORLD_SCALE;
    const worldY = (y - BOARD.y) / WORLD_SCALE;
    return physics.ballAt(worldX, worldY);
  }
  function onBoardClick(x, y) {
    const ball = ballAt(x, y);
    if (!ball) return;
    if (mode === 'hammer') {
      physics.removeById(ball.id); coins -= prices.hammer;
      mode = null; selectedId = null; playSound('click', 250); persist();
    } else if (mode === 'swap') {
      if (selectedId === null) { selectedId = ball.id; playSound('click', 490); }
      else if (selectedId === ball.id) { selectedId = null; }
      else {
        if (physics.swapByIds(selectedId, ball.id)) { coins -= prices.swap; playSound('click', 500); }
        mode = null; selectedId = null; persist();
      }
    } else {
      const result = physics.click((x - BOARD.x) / WORLD_SCALE, (y - BOARD.y) / WORLD_SCALE);
      if (!result) { clickFlash = { id: ball.id, time: .2 }; }
    }
  }
  function localPointer(event) {
    const rect = canvas.getBoundingClientRect();
    return { x: ((event.clientX - rect.left) - originX) / scale, y: ((event.clientY - rect.top) - originY) / scale };
  }
  canvas.addEventListener('pointerdown', event => {
    event.preventDefault(); canvas.focus({ preventScroll: true });
    // За время перехода нельзя повторно выбрать уже удалённые шарики.
    if (mergeAnimation) return;
    const p = localPointer(event);
    for (let i = buttons.length - 1; i >= 0; i--) {
      const b = buttons[i];
      if (p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h) {
        playSound('click', 520);
        b.action();
        return;
      }
    }
    if (!modal && p.x >= BOARD.x && p.x <= BOARD.x + BOARD.w && p.y >= BOARD.y && p.y <= BOARD.y + BOARD.h) onBoardClick(p.x, p.y);
  });
  canvas.addEventListener('pointermove', event => {
    if (event.pointerType !== 'mouse') { hoveredId = null; hoveredButtonLabel = null; return; }
    const p = localPointer(event); const ball = modal ? null : ballAt(p.x, p.y);
    hoveredId = ball ? ball.id : null;
    const overButton = [...buttons].reverse().find(b => p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h);
    const nextButtonLabel = overButton ? overButton.label : null;
    if (nextButtonLabel && nextButtonLabel !== hoveredButtonLabel) playSound('hover', 680, .08);
    hoveredButtonLabel = nextButtonLabel;
    canvas.style.cursor = overButton || ball ? 'pointer' : 'default';
  });
  canvas.addEventListener('pointerleave', () => { hoveredId = null; hoveredButtonLabel = null; });
  window.addEventListener('keydown', event => {
    if (event.key === 'Escape') { if (modal) modal = null; else { mode = null; selectedId = null; } }
  });
  window.addEventListener('pagehide', persist);
  document.addEventListener('visibilitychange', () => { if (document.hidden) persist(); lastTime = 0; });

  function frame(timestamp) {
    const dt = lastTime ? Math.min(MAX_DT, (timestamp - lastTime) / 1000) : 0;
    lastTime = timestamp;
    // Как и в оригинале, поле не «замерзает» из-за эффекта объединения.
    // Пока открыта модалка, как и раньше, игра ставится на паузу.
    if (!modal && dt > 0) physics.update(dt);
    if (!modal && mergeAnimation) {
      mergeAnimation.age += dt;
      followMergeTarget();
      if (mergeAnimation.age >= mergeAnimation.duration) {
        const completed = mergeAnimation;
        mergeAnimation = null;
        animation.push(completed.scoreEffect);
        if (completed.reachedGoal !== null) {
          modal = { type: 'goalReached', value: completed.reachedGoal };
          playSound('goal', 900, .25);
        }
      }
    }
    if (toast) { toast.left -= dt; if (toast.left <= 0) toast = null; }
    if (clickFlash) { clickFlash.time -= dt; if (clickFlash.time <= 0) clickFlash = null; }
    animation = animation.filter(item => { item.age += dt; return item.age < 1.1; });
    saveTimer += dt;
    if (saveTimer > 5) { saveTimer = 0; if (!modal) persist(); }
    const dpr = canvas.width / width;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawBackground();
    ctx.save(); ctx.translate(originX, originY); ctx.scale(scale, scale);
    buttons = [];
    drawBoard(); drawTop(); drawBottom(); drawToast();
    if (modal) buttons = [];
    drawModal();
    ctx.restore();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
