/*
 * BubblePhysics — независимая логика для Canvas 2D, без модулей и зависимостей.
 * Подключение: <script src="/physics.js"></script>, затем new BubblePhysics({...}).
 * update(dt): секунды; click(x, y): координаты поля 500×710.
 * balls — живой массив {id, x, y, vx, vy, value, r}; отрисовка отдельно.
 * state: "playing" или "no-moves". Состояние без ходов сообщается после
 * успокоения поля; столкновения никогда не выполняют слияние.
 * onMerge({ball, value, count, scoreAdded, sources}); onChange(game) вызывается после
 * действий/загрузки и смены state, но НЕ на каждом физическом кадре.
 * onNoMoves(game) вызывается один раз при переходе в состояние "no-moves".
 * serialize() возвращает обычный объект; load(object | JSON string) атомарно
 * проверяет данные и возвращает true/false. Остальные действия тоже возвращают
 * true при изменении и false при отсутствии результата.
 */
(function (global) {
  'use strict';

  const WIDTH = 500;
  const HEIGHT = 710;
  // Unity RulesSO: baseBallRadius=0.41, ballRadiusStep=(0, 0.01), fieldWidth=5.
  // Recovered GetBallRadius body: return base radius when value <= baseValue;
  // otherwise add step.y * (value - baseValue). The original call-site mapping
  // from displayed nominal to these integer arguments remains unconfirmed.
  const FIELD_WIDTH = 5;
  // RulesSO spawnTopHeight=9, mapped from the field floor into Canvas pixels.
  // The Unity method call-site/camera transform is unavailable, so this is a
  // documented coordinate approximation rather than an exact scene transform.
  const SPAWN_TOP_HEIGHT = 9;
  const SPAWN_CENTER_Y = HEIGHT - SPAWN_TOP_HEIGHT * WIDTH / FIELD_WIDTH;
  const BASE_RADIUS = 0.41 * WIDTH / FIELD_WIDTH;
  const RADIUS_STEP = 0.01 * WIDTH / FIELD_WIDTH;
  const INITIAL_COUNT = 55;
  const MAX_BALLS = 128;
  const MAX_EXPONENT = 52;
  const MAX_VALUE = 2 ** MAX_EXPONENT;
  const MAX_SPEED = 700;
  const MAX_ANGULAR_SPEED = 30;
  // Canvas sleep estimate (not an extracted Unity setting): center net drift
  // <=0.1px, accumulated path <=1.5px and residual spin <=1.2rad/s over 0.8s.
  const SLEEP_WINDOW = 0.8;
  const MAX_SLEEP_DRIFT = 0.1;
  const MAX_SLEEP_TRAVEL = 1.5;
  const MAX_SLEEP_ANGULAR_SPEED = 1.2;
  const MAX_SLEEP_PENETRATION = 0.35;
  const MAX_DT = 0.1;
  const MAX_STEP = 1 / 120;
  // Physics2D project gravity was not in the extracted dump; use Unity's
  // default 9.81 units/s^2 scaled by the confirmed 500px / 5-unit field.
  const GRAVITY = 9.81 * WIDTH / FIELD_WIDTH;
  const RESTITUTION = 0.25;
  const WALL_RESTITUTION = 0;
  // Ball Rigidbody2D: mass=1, linearDamping=0.1, angularDamping=0.05;
  // its CircleCollider2D material has friction=0.05 and bounce=0.25.
  const LINEAR_DAMPING = 0.1;
  const ANGULAR_DAMPING = 0.05;
  const BALL_FRICTION = 0.05;
  const WALL_FRICTION = 0.05;
  const SOLVER_PASSES = 48;
  const NEIGHBOR_FACTOR = 1.10;
  const VALUES = [2, 2, 2, 4, 4, 4, 8, 8, 16, 16, 32, 64];

  const clamp = (number, min, max) => Math.max(min, Math.min(max, number));
  const isFiniteNumber = (number) => typeof number === 'number' && Number.isFinite(number);

  function validValue(value) {
    if (!isFiniteNumber(value) || value < 2 || value > MAX_VALUE) return false;
    const power = Math.round(Math.log2(value));
    return power >= 1 && power <= MAX_EXPONENT && 2 ** power === value;
  }

  function radiusForValue(value) {
    // The clone stores displayed powers of two (2, 4, 8...) as `value`; use
    // their tier index and a base tier of 1 until the Unity call-site mapping
    // is fully recovered. This is explicit, not a claim about raw Unity input.
    const tierIndex = Math.max(1, Math.log2(value));
    const baseTierIndex = 1;
    if (tierIndex <= baseTierIndex) return BASE_RADIUS;
    return BASE_RADIUS + RADIUS_STEP * (tierIndex - baseTierIndex);
  }

  function planRows(values) {
    const gap = 0.25;
    const rows = [];
    let offset = 0;
    while (offset < values.length) {
      let count = Math.min(6, values.length - offset);
      const rowWidth = (size) => values.slice(offset, offset + size)
        .reduce((sum, value) => sum + 2 * radiusForValue(value), 0) + gap * (size - 1);
      while (count > 1 && rowWidth(count) > WIDTH) count--;
      const rowValues = values.slice(offset, offset + count);
      const width = rowWidth(count);
      const margin = (WIDTH - width) / 2;
      const shift = rows.length % 2 ? Math.max(0, margin - 0.1) : 0;
      let cursor = margin + shift;
      const balls = rowValues.map((value, index) => {
        const r = radiusForValue(value);
        cursor += r;
        const ball = { x: cursor, r, value };
        cursor += r + (index < rowValues.length - 1 ? gap : 0);
        return ball;
      });
      rows.push({ balls, maxRadius: Math.max(...balls.map((ball) => ball.r)), gap, y: 0 });
      offset += count;
    }
    return rows;
  }

  function rowSpacing(lower, upper) {
    let spacing = 0;
    for (const a of lower.balls) for (const b of upper.balls) {
      const dx = Math.abs(a.x - b.x);
      const required = a.r + b.r + Math.max(lower.gap, upper.gap);
      const dy = dx < required ? Math.sqrt(required * required - dx * dx) : 0;
      const offsetDifference = (lower.maxRadius - a.r) - (upper.maxRadius - b.r);
      spacing = Math.max(spacing, dy - offsetDifference);
    }
    return Math.max(0, spacing);
  }

  function limitVelocity(ball) {
    const speed = Math.hypot(ball.vx, ball.vy);
    if (speed > MAX_SPEED) {
      const scale = MAX_SPEED / speed;
      ball.vx *= scale;
      ball.vy *= scale;
    }
  }

  class BubblePhysics {
    constructor({ onMerge, onChange, onNoMoves } = {}) {
      this.onMerge = typeof onMerge === 'function' ? onMerge : null;
      this.onChange = typeof onChange === 'function' ? onChange : null;
      this.onNoMoves = typeof onNoMoves === 'function' ? onNoMoves : null;
      this.balls = [];
      this.score = 0;
      this.highest = 0;
      this.state = 'playing';
      this._nextId = 1;
      this._quietTime = 0;
      this._sleeping = false;
      this._sleepPositions = null;
      this._sleepTravel = null;
      this._stateCheckTime = 0;
      // При конструировании не вызываем колбэки до возвращения экземпляра.
      this._reset(false);
    }

    _notify() {
      if (this.onChange) this.onChange(this);
    }

    _markActive() {
      this.state = 'playing';
      this._quietTime = 0;
      this._sleeping = false;
      this._sleepPositions = null;
      this._sleepTravel = null;
      this._stateCheckTime = 0;
    }

    _newId() {
      // Перенос на начало позволяет безопасно читать даже сохранение с MAX_SAFE_INTEGER.
      let id = this._nextId;
      while (this.balls.some((ball) => ball.id === id)) {
        id = id >= Number.MAX_SAFE_INTEGER ? 1 : id + 1;
      }
      this._nextId = id >= Number.MAX_SAFE_INTEGER ? 1 : id + 1;
      return id;
    }

    _randomValue() {
      return VALUES[Math.floor(Math.random() * VALUES.length)];
    }

    _makeBall(x, y, value) {
      return {
        id: this._newId(), x, y, vx: 0, vy: 0, angle: 0, angularVelocity: 0,
        value, r: radiusForValue(value)
      };
    }

    _reset(notify) {
      this.balls.length = 0;
      this._nextId = 1;
      this.score = 0;
      this.highest = 0;
      this._markActive();

      const values = Array.from({ length: INITIAL_COUNT }, (_, index) =>
        index < 2 ? 2 : this._randomValue());
      const rows = planRows(values);
      rows[0].y = HEIGHT - rows[0].maxRadius;
      for (let row = 1; row < rows.length; row++) {
        rows[row].y = rows[row - 1].y - rowSpacing(rows[row - 1], rows[row]);
      }
      for (const row of rows) for (const item of row.balls) {
        const ball = this._makeBall(item.x, row.y + row.maxRadius - item.r, item.value);
        this.balls.push(ball);
        this.highest = Math.max(this.highest, item.value);
      }
      if (notify) this._notify();
      return true;
    }

    reset() {
      return this._reset(true);
    }

    _walls(ball, floorFriction, step) {
      if (ball.x < ball.r) {
        ball.x = ball.r;
        if (ball.vx < 0) {
          const normalImpulse = -ball.vx;
          ball.vx = -normalImpulse * WALL_RESTITUTION;
          if (floorFriction) this._wallFriction(ball, -1, normalImpulse);
        }
      } else if (ball.x > WIDTH - ball.r) {
        ball.x = WIDTH - ball.r;
        if (ball.vx > 0) {
          const normalImpulse = ball.vx;
          ball.vx = -normalImpulse * WALL_RESTITUTION;
          if (floorFriction) this._wallFriction(ball, 1, normalImpulse);
        }
      }
      // Верх намеренно открыт для пополнения.
      if (ball.y > HEIGHT - ball.r) {
        ball.y = HEIGHT - ball.r;
        let normalImpulse = GRAVITY * step;
        if (ball.vy > 0) {
          normalImpulse += ball.vy;
          ball.vy = 0;
        }
        if (floorFriction && step > 0) {
          // Circle inertia is approximated as a uniform disk, I = m*r^2/2.
          const inertia = 0.5 * ball.r * ball.r;
          const contactVelocity = ball.vx - ball.angularVelocity * ball.r;
          const tangentImpulse = clamp(-contactVelocity / 3,
            -WALL_FRICTION * normalImpulse, WALL_FRICTION * normalImpulse);
          ball.vx += tangentImpulse;
          ball.angularVelocity -= tangentImpulse * ball.r / inertia;
        }
      }
    }

    _wallFriction(ball, side, normalImpulse) {
      const inertia = 0.5 * ball.r * ball.r;
      const contactVelocity = ball.vy + ball.angularVelocity * side * ball.r;
      const tangentImpulse = clamp(-contactVelocity / 3,
        -WALL_FRICTION * normalImpulse, WALL_FRICTION * normalImpulse);
      ball.vy += tangentImpulse;
      ball.angularVelocity += side * ball.r * tangentImpulse / inertia;
    }

    _solvePair(a, b, resolveVelocity = true) {
      let dx = b.x - a.x;
      let dy = b.y - a.y;
      const radius = a.r + b.r;
      const distanceSquared = dx * dx + dy * dy;
      if (distanceSquared >= radius * radius) return;

      let distance = Math.sqrt(distanceSquared);
      let nx;
      let ny;
      if (distance < 1e-8) {
        // Совпавшие центры раздвигаем предсказуемо, не деля на ноль.
        nx = (a.id + b.id) % 2 ? 1 : 0;
        ny = nx ? 0 : 1;
        distance = 0;
      } else {
        nx = dx / distance;
        ny = dy / distance;
      }

      const correction = (radius - distance) / 2;
      a.x -= nx * correction;
      a.y -= ny * correction;
      b.x += nx * correction;
      b.y += ny * correction;
      if (!resolveVelocity) return;

      const rvx = b.vx - a.vx;
      const rvy = b.vy - a.vy;
      const normalSpeed = rvx * nx + rvy * ny;
      let normalImpulse = 0;
      if (normalSpeed < 0) {
        // Небольшие столкновения не подпрыгивают бесконечно.
        const bounce = RESTITUTION;
        const impulse = -(1 + bounce) * normalSpeed / 2;
        normalImpulse = impulse;
        a.vx -= impulse * nx;
        a.vy -= impulse * ny;
        b.vx += impulse * nx;
        b.vy += impulse * ny;

      }
      if (normalImpulse > 0) {
        const tx = -ny;
        const ty = nx;
        const raX = nx * a.r, raY = ny * a.r;
        const rbX = -nx * b.r, rbY = -ny * b.r;
        const contactAVx = a.vx - a.angularVelocity * raY;
        const contactAVy = a.vy + a.angularVelocity * raX;
        const contactBVx = b.vx - b.angularVelocity * rbY;
        const contactBVy = b.vy + b.angularVelocity * rbX;
        const tangentSpeed = (contactBVx - contactAVx) * tx + (contactBVy - contactAVy) * ty;
        const inertiaA = 0.5 * a.r * a.r;
        const inertiaB = 0.5 * b.r * b.r;
        const crossA = raX * ty - raY * tx;
        const crossB = rbX * ty - rbY * tx;
        const denominator = 2 + crossA * crossA / inertiaA + crossB * crossB / inertiaB;
        const tangentImpulse = clamp(-tangentSpeed / denominator,
          -BALL_FRICTION * normalImpulse, BALL_FRICTION * normalImpulse);
        const impulseX = tangentImpulse * tx;
        const impulseY = tangentImpulse * ty;
        a.vx -= impulseX;
        a.vy -= impulseY;
        b.vx += impulseX;
        b.vy += impulseY;
        a.angularVelocity -= (raX * impulseY - raY * impulseX) / inertiaA;
        b.angularVelocity += (rbX * impulseY - rbY * impulseX) / inertiaB;
      }
    }

    _maxPenetration() {
      let maximum = 0;
      for (let i = 0; i < this.balls.length; i++) {
        const a = this.balls[i];
        for (let j = i + 1; j < this.balls.length; j++) {
          const b = this.balls[j];
          maximum = Math.max(maximum, a.r + b.r - Math.hypot(b.x - a.x, b.y - a.y));
        }
      }
      return maximum;
    }

    _relaxOverlaps() {
      const tolerance = 0.12;
      for (let pass = 0; pass < 100; pass++) {
        let maximum = 0;
        for (let i = 0; i < this.balls.length; i++) {
          const a = this.balls[i];
          for (let j = i + 1; j < this.balls.length; j++) {
            const b = this.balls[j];
            const penetration = a.r + b.r - Math.hypot(b.x - a.x, b.y - a.y);
            maximum = Math.max(maximum, penetration);
            if (penetration > 0.01) this._solvePair(a, b, false);
          }
        }
        for (const ball of this.balls) this._walls(ball, false, 0);
        if (maximum <= tolerance) break;
      }
      return this._maxPenetration();
    }

    update(dt) {
      if (!isFiniteNumber(dt) || dt <= 0) return false;
      // Долгую паузу вкладки не пытаемся догонять одним тяжёлым кадром.
      dt = Math.min(dt, MAX_DT);
      // Шар с явно изменённой извне скоростью также будит спящую стопку.
      if (this._sleeping && this.balls.some((ball) => ball.vx !== 0 || ball.vy !== 0 || Math.abs(ball.angularVelocity) > 0.02)) {
        this._sleeping = false;
        this._quietTime = 0;
        this._sleepPositions = null;
        this._sleepTravel = null;
      }
      if (this._sleeping) {
        this._updateState(dt);
        return true;
      }
      if (!this._sleepPositions || this._sleepPositions.length !== this.balls.length) {
        this._sleepPositions = this.balls.map((ball) => [ball.x, ball.y]);
        this._sleepTravel = this.balls.map(() => 0);
      }
      const frameStartPositions = this.balls.map((ball) => [ball.x, ball.y]);
      const steps = Math.ceil(dt / MAX_STEP);
      const step = dt / steps;
      const airDrag = Math.exp(-LINEAR_DAMPING * step);

      for (let substep = 0; substep < steps; substep++) {
        for (const ball of this.balls) {
          ball.vx *= airDrag;
          ball.vy = (ball.vy + GRAVITY * step) * airDrag;
          ball.angularVelocity *= Math.exp(-ANGULAR_DAMPING * step);
          ball.angle = (ball.angle + ball.angularVelocity * step) % (Math.PI * 2);
          limitVelocity(ball);
          ball.angularVelocity = clamp(ball.angularVelocity, -MAX_ANGULAR_SPEED, MAX_ANGULAR_SPEED);
          ball.x += ball.vx * step;
          ball.y += ball.vy * step;
          this._walls(ball, true, step);
        }
        // Каждая неупорядоченная пара рассматривается только один раз за
        // проход; несколько проходов стабилизируют плотные неподвижные стопки.
        for (let pass = 0; pass < SOLVER_PASSES; pass++) {
          for (let i = 0; i < this.balls.length; i++) {
            const a = this.balls[i];
            for (let j = i + 1; j < this.balls.length; j++) {
              this._solvePair(a, this.balls[j]);
            }
          }
          for (const ball of this.balls) this._walls(ball, false, step);
        }
        for (const ball of this.balls) {
          limitVelocity(ball);
          if (Math.abs(ball.vx) < 0.01) ball.vx = 0;
          if (Math.abs(ball.vy) < 0.01) ball.vy = 0;
          if (Math.abs(ball.angularVelocity) < 0.015) ball.angularVelocity = 0;
        }
      }
      // Contact corrections can make frame-to-frame movement look noisy while
      // centers remain fixed over time. Compare both net drift and accumulated
      // path, so real motion that returns to its start is not treated as jitter.
      for (let i = 0; i < this.balls.length; i++) {
        const ball = this.balls[i];
        this._sleepTravel[i] += Math.hypot(
          ball.x - frameStartPositions[i][0], ball.y - frameStartPositions[i][1]);
      }
      this._quietTime += dt;
      if (this._quietTime >= SLEEP_WINDOW) {
        let maxDrift = 0;
        let maxTravel = 0;
        let maxAngularSpeed = 0;
        for (let i = 0; i < this.balls.length; i++) {
          const ball = this.balls[i];
          maxDrift = Math.max(maxDrift,
            Math.hypot(ball.x - this._sleepPositions[i][0], ball.y - this._sleepPositions[i][1]));
          maxTravel = Math.max(maxTravel, this._sleepTravel[i]);
          maxAngularSpeed = Math.max(maxAngularSpeed, Math.abs(ball.angularVelocity));
        }
        this._quietTime = 0;
        if (maxDrift <= MAX_SLEEP_DRIFT && maxTravel <= MAX_SLEEP_TRAVEL &&
            maxAngularSpeed <= MAX_SLEEP_ANGULAR_SPEED &&
            this._relaxOverlaps() <= MAX_SLEEP_PENETRATION) {
          for (const ball of this.balls) ball.vx = ball.vy = ball.angularVelocity = 0;
          this._sleeping = true;
          this._sleepPositions = null;
          this._sleepTravel = null;
        } else {
          this._sleepPositions = this.balls.map((ball) => [ball.x, ball.y]);
          this._sleepTravel = this.balls.map(() => 0);
        }
      }
      this._updateState(dt);
      return true;
    }

    _updateState(dt) {
      this._stateCheckTime += dt;
      // Не пересчитываем все пары каждый кадр и не объявляем конец игры,
      // пока новые шары падают и меняют соседей.
      if (this._stateCheckTime < 0.25) return;
      this._stateCheckTime = 0;
      if (this.state === 'no-moves') {
        if (this.hasMoves()) {
          this.state = 'playing';
          this._notify();
        }
      } else if (this._sleeping && !this.hasMoves()) {
        this.state = 'no-moves';
        this._notify();
        if (this.state === 'no-moves' && this.onNoMoves) this.onNoMoves(this);
      }
    }

    getGroup(ball) {
      if (!ball || !this.balls.includes(ball)) return [];
      const group = [ball];
      const visited = new Set([ball.id]);
      // Обход по массиву даёт детерминированную транзитивную компоненту.
      for (let index = 0; index < group.length; index++) {
        const current = group[index];
        for (const candidate of this.balls) {
          if (visited.has(candidate.id) || candidate.value !== ball.value) continue;
          const dx = current.x - candidate.x;
          const dy = current.y - candidate.y;
          const distance = NEIGHBOR_FACTOR * (current.r + candidate.r);
          if (dx * dx + dy * dy <= distance * distance) {
            visited.add(candidate.id);
            group.push(candidate);
          }
        }
      }
      return group;
    }

    hasMoves() {
      for (let i = 0; i < this.balls.length; i++) {
        const a = this.balls[i];
        for (let j = i + 1; j < this.balls.length; j++) {
          const b = this.balls[j];
          if (a.value !== b.value) continue;
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const distance = NEIGHBOR_FACTOR * (a.r + b.r);
          if (dx * dx + dy * dy <= distance * distance) return true;
        }
      }
      return false;
    }

    _refill(count) {
      if (count <= 0) return;
      // Start at the Unity RulesSO spawn height, not just above the visible
      // pile; if the pile already exceeds it, place the row above that pile.
      let top = 0;
      for (const ball of this.balls) top = Math.min(top, ball.y - ball.r);
      const rows = planRows(Array.from({ length: count }, () => this._randomValue()));
      rows[0].y = Math.min(SPAWN_CENTER_Y, top - rows[0].maxRadius - 3);
      for (let row = 1; row < rows.length; row++) {
        rows[row].y = rows[row - 1].y - rowSpacing(rows[row - 1], rows[row]);
      }
      for (const row of rows) for (const item of row.balls) {
        const ball = this._makeBall(item.x, row.y + row.maxRadius - item.r, item.value);
        this.balls.push(ball);
        this.highest = Math.max(this.highest, item.value);
      }
    }

    ballAt(x, y) {
      if (!isFiniteNumber(x) || !isFiniteNumber(y)) return null;
      // Последний нарисованный шар — верхний слой при визуальном перекрытии.
      for (let i = this.balls.length - 1; i >= 0; i--) {
        const ball = this.balls[i];
        const dx = x - ball.x;
        const dy = y - ball.y;
        if (dx * dx + dy * dy <= ball.r * ball.r) return ball;
      }
      return null;
    }

    click(x, y) {
      if (!isFiniteNumber(x) || !isFiniteNumber(y)) return false;
      const selected = this.ballAt(x, y);
      if (!selected) return false;
      const group = this.getGroup(selected);
      if (group.length < 2) return false;

      // Сохраняем исходный вид и координаты до изменения/удаления тел:
      // Canvas использует снимки для анимации схождения всей группы.
      const sources = group.map(({ id, x, y, r, value, angle, angularVelocity }) =>
        ({ id, x, y, r, value, angle, angularVelocity }));
      const oldPower = Math.log2(selected.value);
      const scoreAdded = 2 * oldPower * (group.length - 1);
      const exponent = Math.min(MAX_EXPONENT, oldPower + group.length - 1);
      const value = 2 ** exponent;
      const removed = new Set(group.slice(1).map((ball) => ball.id));
      for (let i = this.balls.length - 1; i >= 0; i--) {
        if (removed.has(this.balls[i].id)) this.balls.splice(i, 1);
      }
      selected.value = value;
      selected.r = radiusForValue(value);
      this.score = Math.min(Number.MAX_SAFE_INTEGER, this.score + scoreAdded);
      this.highest = Math.max(this.highest, value);
      this._refill(group.length - 1);
      this._markActive();
      if (this.onMerge) this.onMerge({ ball: selected, value, count: group.length, scoreAdded, sources });
      this._notify();
      return true;
    }

    shake() {
      if (!this.balls.length) return false;
      for (const ball of this.balls) {
        ball.vx += (Math.random() * 2 - 1) * 250;
        ball.vy -= 170 + Math.random() * 150;
        limitVelocity(ball);
      }
      this._markActive();
      this._notify();
      return true;
    }

    swapByIds(id1, id2) {
      if (id1 === id2) return false;
      const a = this.balls.find((ball) => ball.id === id1);
      const b = this.balls.find((ball) => ball.id === id2);
      if (!a || !b) return false;
      // Меняются места и скорости; идентификаторы, значения и радиусы остаются.
      [a.x, b.x] = [b.x, a.x];
      [a.y, b.y] = [b.y, a.y];
      [a.vx, b.vx] = [b.vx, a.vx];
      [a.vy, b.vy] = [b.vy, a.vy];
      [a.angle, b.angle] = [b.angle, a.angle];
      [a.angularVelocity, b.angularVelocity] = [b.angularVelocity, a.angularVelocity];
      this._walls(a, false, 0);
      this._walls(b, false, 0);
      this._markActive();
      this._notify();
      return true;
    }

    removeById(id) {
      const index = this.balls.findIndex((ball) => ball.id === id);
      if (index < 0) return false;
      this.balls.splice(index, 1);
      this._markActive();
      this._notify();
      return true;
    }

    serialize() {
      return {
        version: 1,
        balls: this.balls.map(({ id, x, y, vx, vy, angle, angularVelocity, value, r }) =>
          ({ id, x, y, vx, vy, angle, angularVelocity, value, r })),
        score: this.score,
        highest: this.highest,
        state: this.state
      };
    }

    load(data) {
      if (typeof data === 'string') {
        try { data = JSON.parse(data); } catch (_) { return false; }
      }
      if (!data || typeof data !== 'object' || Array.isArray(data) ||
          (data.version !== undefined && data.version !== 1) ||
          !Array.isArray(data.balls) || data.balls.length > MAX_BALLS ||
          !Number.isSafeInteger(data.score) || data.score < 0 ||
          !(data.highest === 0 || validValue(data.highest)) ||
          (data.state !== undefined && data.state !== 'playing' && data.state !== 'no-moves')) return false;

      const balls = [];
      const ids = new Set();
      let maxId = 0;
      let maxValue = 0;
      for (const item of data.balls) {
        if (!item || typeof item !== 'object' || !Number.isSafeInteger(item.id) || item.id < 1 ||
            ids.has(item.id) || !validValue(item.value) ||
            (item.r !== undefined && (!isFiniteNumber(item.r) || item.r < 20 || item.r > 100)) ||
            (item.angle !== undefined && (!isFiniteNumber(item.angle) || Math.abs(item.angle) > 1e6)) ||
            (item.angularVelocity !== undefined && (!isFiniteNumber(item.angularVelocity) || Math.abs(item.angularVelocity) > MAX_ANGULAR_SPEED)) ||
            !isFiniteNumber(item.x) || !isFiniteNumber(item.y) ||
            !isFiniteNumber(item.vx) || !isFiniteNumber(item.vy)) return false;
        ids.add(item.id);
        maxId = Math.max(maxId, item.id);
        maxValue = Math.max(maxValue, item.value);
        const radius = radiusForValue(item.value);
        const ball = {
          id: item.id,
          x: clamp(item.x, radius, WIDTH - radius),
          y: clamp(item.y, -10000, HEIGHT - radius),
          vx: item.vx,
          vy: item.vy,
          angle: item.angle ?? 0,
          angularVelocity: item.angularVelocity ?? 0,
          value: item.value,
          // Ignore legacy fixed r=41 values and derive geometry from value.
          r: radius
        };
        limitVelocity(ball);
        balls.push(ball);
      }
      if (data.highest < maxValue) return false;

      // Изменяем экземпляр только после проверки всего сохранения.
      this.balls.splice(0, this.balls.length, ...balls);
      this.score = data.score;
      this.highest = data.highest;
      this._nextId = maxId >= Number.MAX_SAFE_INTEGER ? 1 : maxId + 1;
      this._markActive();
      if (data.state === 'no-moves' && !this.hasMoves()) this.state = 'no-moves';
      this._notify();
      return true;
    }
  }

  BubblePhysics.radiusForValue = radiusForValue;
  global.BubblePhysics = BubblePhysics;
})(window);
