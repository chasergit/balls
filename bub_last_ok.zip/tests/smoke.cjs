// Headless integration smoke test; uses only Node's built-in modules.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');

function createHarness(initialSave) {
  const handlers = {};
  const store = {};
  const drawnText = [];
  const drawnImages = [];
  const drawnRotations = [];
  let canvasX = 0, canvasY = 0;
  let canvasAngle = 0;
  const canvasStack = [];
  const playedAudio = [];
  if (initialSave) store.bubbles2048_canvas_v1 = JSON.stringify(initialSave);
  const gradient = { addColorStop() {} };
  const ctx = new Proxy({
    drawImage(image, x, y, width, height) { drawnImages.push({ src: image.src, x: x + canvasX, y: y + canvasY, width, height }); },
    fillText(label, x, y) { drawnText.push({ label: String(label), x: x + canvasX, y: y + canvasY, angle: canvasAngle }); },
    save() { canvasStack.push([canvasX, canvasY, canvasAngle]); },
    restore() { [canvasX, canvasY, canvasAngle] = canvasStack.pop() || [0, 0, 0]; },
    translate(x, y) { canvasX += x; canvasY += y; },
    rotate(angle) { canvasAngle += angle; drawnRotations.push(angle); }
  }, {
    get(target, name) {
      if (name === 'createLinearGradient' || name === 'createRadialGradient') return () => gradient;
      return target[name] || (() => {});
    },
    set(target, name, value) { target[name] = value; return true; }
  });
  const canvas = {
    clientWidth: 800, clientHeight: 800, width: 800, height: 800, style: {},
    getContext: () => ctx,
    getBoundingClientRect: () => ({ left: 0, top: 0 }),
    addEventListener: (type, callback) => { handlers[type] = callback; },
    focus() {}
  };
  const deterministicMath = Object.create(Math);
  deterministicMath.random = () => 0.5;
  const probeContext = {
    clearRect() {}, drawImage() {}, fillRect() {},
    getImageData(_x, _y, width, height) {
      const data = new Uint8ClampedArray(width * height * 4);
      for (let y = 60; y <= 78; y++) {
        for (let x = 2; x <= 119; x++) data[(y * width + x) * 4 + 3] = 255;
      }
      return { data };
    }
  };
  let nextFrame;
  const sandbox = {
    console, Math: deterministicMath, Date, Set, JSON, Number, Array, Object, Infinity,
    devicePixelRatio: 1,
    document: {
      getElementById: id => id === 'game' ? canvas : { textContent: '' },
      createElement: () => ({ width: 0, height: 0, getContext: () => probeContext }),
      addEventListener() {}, hidden: false
    },
    Image: class {
      constructor() { this.complete = false; this.naturalWidth = 0; this.naturalHeight = 0; this.onload = null; }
      set src(value) {
        this._src = value; this.complete = true; this.naturalWidth = 122; this.naturalHeight = 128;
        if (this.onload) this.onload();
      }
      get src() { return this._src; }
    },
    Audio: class {
      constructor(src) { this.src = src; this.currentTime = 0; this.volume = 1; this.preload = ''; }
      play() { playedAudio.push(this.src); return Promise.resolve(); }
    },
    localStorage: {
      getItem: key => store[key] || null,
      setItem: (key, value) => { store[key] = value; }
    },
    requestAnimationFrame: cb => { nextFrame = cb; },
    addEventListener() {}
  };
  sandbox.window = sandbox;
  const context = vm.createContext(sandbox);
  for (const file of ['physics.js', 'game.js']) {
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../public', file), 'utf8'), context, { filename: file });
  }
  let t = 1000;
  return {
    sandbox,
    frame() {
      drawnText.length = 0;
      drawnImages.length = 0;
      t += 16;
      const run = nextFrame;
      assert.ok(run, 'animation frame scheduled');
      run(t);
      return drawnText.slice();
    },
    advance(count) { for (let i = 0; i < count; i++) this.frame(); },
    click(x, y) { handlers.pointerdown({ clientX: x, clientY: y, preventDefault() {} }); },
    move(x, y) { handlers.pointermove({ clientX: x, clientY: y, pointerType: 'mouse' }); },
    images() { return drawnImages.slice(); },
    rotations() { return drawnRotations.slice(); },
    audio() { return playedAudio.slice(); },
    save() { return JSON.parse(store.bubbles2048_canvas_v1); }
  };
}

// Physics supplies immutable old positions and values to the renderer.
const unit = createHarness();
let mergeEvent;
const physics = new unit.sandbox.BubblePhysics({ onMerge: event => { mergeEvent = event; } });
assert.ok(physics.load({ version: 1, score: 0, highest: 4, state: 'playing', balls: [
  { id: 1, x: 100, y: 630, vx: 0, vy: 0, r: 41, value: 4 },
  { id: 2, x: 180, y: 630, vx: 0, vy: 0, r: 41, value: 4 }
] }));
assert.equal(physics.ballAt(140, 630).id, 2, 'hit-testing picks the topmost ball in an overlap');
assert.equal(physics.click(140, 630), true);
assert.equal(mergeEvent.ball.id, 2, 'merge uses the same topmost hit-test');
assert.equal(mergeEvent.value, 8);
assert.equal(mergeEvent.scoreAdded, 4);
assert.equal(mergeEvent.ball.r, 43, 'merged ball radius follows its new value level');
assert.equal(mergeEvent.sources.length, 2);
assert.equal(mergeEvent.sources[0].value, 4, 'source keeps old value after target mutates');
assert.equal(mergeEvent.sources[0].x, 180, 'selected topmost source keeps its original position');
assert.equal(mergeEvent.sources[1].x, 100, 'other source keeps its original position');
assert.equal(unit.sandbox.BubblePhysics.radiusForValue(2), 41, 'level-one radius uses serialized baseBallRadius 0.41');
assert.equal(unit.sandbox.BubblePhysics.radiusForValue(4), 42, 'each next level applies the serialized 0.01 step');
assert.equal(unit.sandbox.BubblePhysics.radiusForValue(8), 43, 'radius grows consistently with the logarithmic value level');

const nearTopRefill = new unit.sandbox.BubblePhysics();
assert.ok(nearTopRefill.load({ version: 1, score: 0, highest: 64, balls: [
  { id: 1, x: 100, y: 630, vx: 0, vy: 0, value: 2 },
  { id: 2, x: 180, y: 630, vx: 0, vy: 0, value: 2 },
  { id: 3, x: 250, y: 35, vx: 0, vy: 0, value: 64 }
] }), 'nearly full board loads for refill regression');
assert.equal(nearTopRefill.click(100, 630), true, 'near-top merge triggers a refill');
const incoming = nearTopRefill.balls.find(ball => ball.id === 4);
assert.ok(incoming, 'refill creates the replacement ball');
assert.ok(incoming.y + incoming.r < 0, 'replacement ball begins fully above the board clip instead of showing only its lower edge');

const aboveSpawnRefill = new unit.sandbox.BubblePhysics();
assert.ok(aboveSpawnRefill.load({ version: 1, score: 0, highest: 64, balls: [
  { id: 1, x: 100, y: 630, vx: 0, vy: 0, value: 2 },
  { id: 2, x: 180, y: 630, vx: 0, vy: 0, value: 2 },
  { id: 3, x: 250, y: -260, vx: 0, vy: 0, value: 64 }
] }), 'board already above the normal spawn baseline loads');
assert.equal(aboveSpawnRefill.click(100, 630), true, 'high-stack merge triggers a refill');
const highStackTop = aboveSpawnRefill.balls.find(ball => ball.id === 3).y - aboveSpawnRefill.balls.find(ball => ball.id === 3).r;
const aboveStackSpawn = aboveSpawnRefill.balls.find(ball => ball.id === 4);
assert.ok(aboveStackSpawn.y + aboveStackSpawn.r < highStackTop, 'refill row is moved above a stack that exceeds the normal spawn baseline');

const migrated = new unit.sandbox.BubblePhysics();
assert.ok(migrated.load({ version: 1, score: 0, highest: 8, balls: [
  { id: 1, x: 100, y: 300, vx: 0, vy: 0, r: 41, value: 2 },
  { id: 2, x: 180, y: 300, vx: 0, vy: 0, r: 41, value: 8 }
] }), 'legacy fixed-radius save remains loadable');
assert.equal(migrated.balls[0].r, 41, 'level-one legacy ball restores its base radius');
assert.equal(migrated.balls[1].r, 43, 'legacy saved radius migrates to the value-derived radius');
assert.equal(migrated.balls[0].angle, 0, 'legacy saves default rotation to zero');

const spinPhysics = new unit.sandbox.BubblePhysics();
assert.ok(spinPhysics.load({ version: 1, score: 0, highest: 4, balls: [
  { id: 1, x: 200, y: 300, vx: 120, vy: 60, angle: 0.2, angularVelocity: 0, r: 41, value: 2 },
  { id: 2, x: 270, y: 300, vx: 0, vy: 0, angle: 0, angularVelocity: 0, r: 42, value: 4 }
] }));
spinPhysics.update(1 / 60);
assert.ok(Math.abs(spinPhysics.balls[0].angularVelocity) > 0, 'off-center frictional contact creates angular velocity');
const spinRoundTrip = new unit.sandbox.BubblePhysics();
assert.ok(spinRoundTrip.load(spinPhysics.serialize()), 'angular state survives save/load');
assert.equal(spinRoundTrip.balls[0].angle, spinPhysics.balls[0].angle, 'saved angle is restored');
assert.equal(spinRoundTrip.balls[0].angularVelocity, spinPhysics.balls[0].angularVelocity, 'saved angular velocity is restored');

const fallingSleepGuard = new unit.sandbox.BubblePhysics();
assert.ok(fallingSleepGuard.load({ version: 1, score: 0, highest: 2, balls: [
  { id: 1, x: 250, y: 300, vx: 0, vy: 0, value: 2 }
] }), 'single falling body loads for sleep guard regression');
for (let frame = 0; frame < 60; frame++) fallingSleepGuard.update(1 / 60);
assert.equal(fallingSleepGuard._sleeping, false, 'sleep window never freezes a body with genuine center travel');

const spinningSleepGuard = new unit.sandbox.BubblePhysics();
assert.ok(spinningSleepGuard.load({ version: 1, score: 0, highest: 2, balls: [
  { id: 1, x: 250, y: 300, vx: 0, vy: 0, angularVelocity: 2, value: 2 }
] }), 'spinning body loads for angular sleep guard regression');
for (let frame = 0; frame < 60; frame++) spinningSleepGuard.update(1 / 60);
assert.equal(spinningSleepGuard._sleeping, false, 'sleep window does not freeze clearly visible angular motion');

const spinningGame = createHarness({
  version: 1, best: 0, coins: 0, goal: 1024, sound: false, tutorialSeen: true,
  physics: { version: 1, score: 0, highest: 2, state: 'playing', balls: [
    { id: 1, x: 250, y: 300, vx: 0, vy: 0, angle: 0.75, angularVelocity: 0, r: 41, value: 2 }
  ] }
});
const spinningFrame = spinningGame.frame();
assert.ok(spinningGame.rotations().includes(0.75), 'Canvas rotates the ball artwork by its physics angle');
assert.equal(spinningFrame.find(item => item.label === '2').angle, 0, 'ball denomination remains upright while its artwork rotates');

// The board's rigid bodies keep updating after click starts its visual transition.
assert.ok(physics.load({ version: 1, score: 0, highest: 8, state: 'playing', balls: [
  { id: 1, x: 100, y: 300, vx: 0, vy: 0, r: 41, value: 4 },
  { id: 2, x: 180, y: 300, vx: 0, vy: 0, r: 41, value: 4 },
  { id: 3, x: 350, y: 100, vx: 0, vy: 100, r: 41, value: 8 }
] }));
assert.equal(physics.click(100, 300), true);
const fallingBefore = physics.balls.find(ball => ball.id === 3).y;
for (let i = 0; i < 30; i++) physics.update(1 / 60);
const fallingDuring = physics.balls.find(ball => ball.id === 3).y;
assert.ok(fallingDuring > fallingBefore + 10, 'unrelated balls continue falling during the merge');

const game = createHarness();
game.frame();
game.move(400, 600);
assert.ok(game.audio().includes('./assets/audio/ui-hover.m4a'), 'hover uses the original Unity clip');
game.click(400, 600); // tutorial
game.frame();
game.click(400, 500); // start
game.frame();
let state = game.save();
assert.ok(state && state.physics.balls.length === 55, 'start creates a full field');
assert.ok(game.audio().includes('./assets/audio/ui-click.m4a'), 'interface buttons use the original click clip');
const first = state.physics.balls[0];
const firstBallDraw = game.images().find(draw => draw.src === './assets/balls/2.png');
assert.ok(firstBallDraw, 'ball PNGs are rendered after their alpha geometry is measured');
const artScale = firstBallDraw.width / 122;
const renderedBodyWidth = firstBallDraw.width * 118 / 122;
const collisionDiameter = 2 * first.r * 0.896;
assert.ok(Math.abs(renderedBodyWidth - collisionDiameter * 0.985) < 0.01, 'visible PNG width is calibrated to the collision circle');
assert.ok(Math.abs(firstBallDraw.x + 61 * artScale - (176 + first.x * 0.896)) < 0.01, 'sprite body is centered on the physical x coordinate');
assert.ok(Math.abs(firstBallDraw.y + 69 * artScale - (84 + first.y * 0.896)) < 0.5, 'sprite body remains centered while physics advances after a saved frame');
game.click(176 + first.x * 0.896, 84 + first.y * 0.896);
let early = game.frame();
state = game.save();
assert.ok(state.physics.score > 0, 'clicking the guaranteed adjacent pair merges and scores');
assert.ok(game.audio().includes('./assets/audio/success-pop.m4a'), 'merges use the original success-pop clip');
assert.equal(state.physics.balls.length, 55, 'merging refills the removed balls');
const oldNumbers = early.filter(item => item.label === '2' && item.y > 100);
assert.equal(oldNumbers.length, 2, 'both old balls are drawn at the beginning of the transition');
const firstSourceX = Math.max(...oldNumbers.map(item => item.x));
game.advance(9);
const middle = game.frame().filter(item => item.label === '2' && item.y > 100);
assert.equal(middle.length, 2, 'old balls remain visible while converging');
const movingSourceX = Math.max(...middle.map(item => item.x));
assert.ok(movingSourceX < firstSourceX - 5, 'the neighboring ball visibly moves toward the selected ball');
assert.ok(movingSourceX > 176 + first.x * 0.896 - 4, 'the moving ball follows its live physics target without visibly overshooting');
game.click(304, 63); // ignored until the merge animation finishes
game.frame();
game.click(400, 485);
game.frame();
assert.equal(game.save().coins, 0, 'buttons cannot interrupt a merge in progress');
game.advance(30);
game.click(304, 63); // coin plus after animation
let after = game.frame();
assert.ok(after.some(item => item.label === 'Нужны монеты?'), 'buttons work after animation');
game.click(400, 485); // free coins
game.frame();
state = game.save();
assert.equal(state.coins, 50, 'coin button adds coins');
game.click(540, 750); // hammer
game.frame();
const target = game.save().physics.balls.find(b => b.y > 50 && b.y < 700);
game.click(176 + target.x * 0.896, 84 + target.y * 0.896);
game.frame();
state = game.save();
assert.equal(state.coins, 0, 'hammer spends its cost');
assert.equal(state.physics.balls.length, 54, 'hammer removes a ball');

const overlapHammer = createHarness({
  version: 1, best: 0, coins: 50, goal: 1024, sound: false, tutorialSeen: true,
  physics: { version: 1, score: 0, highest: 4, state: 'playing', balls: [
    { id: 1, x: 300, y: 400, vx: 0, vy: 0, r: 41, value: 2 },
    { id: 2, x: 320, y: 400, vx: 0, vy: 0, r: 41, value: 4 }
  ] }
});
overlapHammer.frame();
overlapHammer.click(540, 750); // arm the hammer
overlapHammer.click(176 + 310 * 0.896, 84 + 400 * 0.896); // both circles contain this point
overlapHammer.frame();
assert.deepEqual(overlapHammer.save().physics.balls.map(ball => ball.id), [1], 'hammer acts on the topmost ball selected by the shared hit-test');
assert.equal(overlapHammer.audio().length, 0, 'muted saved games never play original clips');

// Reaching a goal must not cover the animation or grant the reward repeatedly.
const goalGame = createHarness({
  version: 1, best: 0, coins: 0, goal: 1024, sound: false, tutorialSeen: true,
  physics: { version: 1, score: 0, highest: 512, state: 'playing', balls: [
    { id: 1, x: 100, y: 630, vx: 0, vy: 0, r: 41, value: 512 },
    { id: 2, x: 180, y: 630, vx: 0, vy: 0, r: 41, value: 512 }
  ] }
});
goalGame.frame();
goalGame.click(176 + 100 * 0.896, 84 + 630 * 0.896);
let goalFrame = goalGame.frame();
assert.equal(goalFrame.some(item => item.label === 'Новая цель!'), false, 'goal dialog waits for animation');
goalGame.advance(36);
goalFrame = goalGame.frame();
assert.ok(goalFrame.some(item => item.label === 'Новая цель!'), 'goal dialog opens after animation');
assert.equal(goalGame.save().coins, 50, 'goal grants one reward');
assert.equal(goalGame.save().goal, 2048, 'goal advances exactly once');

const noMovesGame = createHarness({
  version: 1, best: 0, coins: 0, goal: 1024, sound: false, tutorialSeen: true,
  physics: { version: 1, score: 0, highest: 2, state: 'no-moves', balls: [
    { id: 1, x: 250, y: 630, vx: 0, vy: 0, r: 41, value: 2 }
  ] }
});
assert.ok(noMovesGame.frame().some(item => item.label === 'Нет ходов'), 'a restored no-moves save reopens its dialog');

function maximumPenetration(balls) {
  let maximum = 0;
  for (let i = 0; i < balls.length; i++) for (let j = i + 1; j < balls.length; j++) {
    maximum = Math.max(maximum, balls[i].r + balls[j].r - Math.hypot(balls[i].x - balls[j].x, balls[i].y - balls[j].y));
  }
  return maximum;
}
for (const hz of [30, 60, 120]) {
  const settled = new unit.sandbox.BubblePhysics();
  settled.reset();
  for (let frame = 0; frame < hz * 12; frame++) settled.update(1 / hz);
  assert.equal(settled._sleeping, true, `starting stack sleeps after settling at ${hz} Hz`);
  assert.ok(maximumPenetration(settled.balls) <= 0.15, `settled stack has no visible penetration at ${hz} Hz`);
}

const originalRandom = unit.sandbox.Math.random;
let seed = 1;
unit.sandbox.Math.random = () => {
  seed = (1664525 * seed + 1013904223) >>> 0;
  return seed / 4294967296;
};
const mixed = new unit.sandbox.BubblePhysics();
unit.sandbox.Math.random = originalRandom;
assert.ok(mixed.balls.some(ball => ball.value === 4), 'mixed seed includes value 4');
assert.ok(mixed.balls.some(ball => ball.value === 64), 'mixed seed includes value 64');
for (let frame = 0; frame < 60 * 12; frame++) mixed.update(1 / 60);
assert.equal(mixed._sleeping, true, 'mixed random starting stack sleeps within 12 seconds');
assert.ok(maximumPenetration(mixed.balls) <= 0.15, 'mixed random starting stack settles without visible penetration');

seed = 1;
unit.sandbox.Math.random = () => {
  seed = (1664525 * seed + 1013904223) >>> 0;
  return seed / 4294967296;
};
const postRefillSpin = new unit.sandbox.BubblePhysics();
const mergeTarget = postRefillSpin.balls[0];
assert.equal(postRefillSpin.click(mergeTarget.x, mergeTarget.y), true, 'seeded real merge creates the spin regression state');
unit.sandbox.Math.random = originalRandom;
for (let frame = 0; frame < 60 * 12; frame++) postRefillSpin.update(1 / 60);
assert.equal(postRefillSpin.balls.length, 55, 'merge/refill preserves the board population');
assert.equal(postRefillSpin._sleeping, true, 'settled merge/refill stack sleeps after center drift becomes negligible');
assert.ok(postRefillSpin.balls.every(ball => ball.angularVelocity === 0), 'sleep clears residual spin on all balls');
const settledAngles = postRefillSpin.balls.map(ball => ball.angle);
for (let frame = 0; frame < 60; frame++) postRefillSpin.update(1 / 60);
assert.deepEqual(postRefillSpin.balls.map(ball => ball.angle), settledAngles, 'sleep keeps settled ball rotation fixed');

seed = 4;
unit.sandbox.Math.random = () => {
  seed = (1664525 * seed + 1013904223) >>> 0;
  return seed / 4294967296;
};
const solverJitterSpin = new unit.sandbox.BubblePhysics();
const jitterTarget = solverJitterSpin.balls[0];
assert.equal(solverJitterSpin.click(jitterTarget.x, jitterTarget.y), true, 'second seed creates a dense post-refill contact island');
unit.sandbox.Math.random = originalRandom;
for (let frame = 0; frame < 60 * 12; frame++) solverJitterSpin.update(1 / 60);
assert.equal(solverJitterSpin._sleeping, true, 'contact solver jitter does not keep a stable post-refill island awake');
assert.ok(solverJitterSpin.balls.every(ball => ball.angularVelocity === 0), 'the dense island stops residual spin');

console.log('PASS: variable radii, spawn height, original rotation/damping/friction, angular collision impulses, rotation save/restore and rendering, legacy migration, audio, geometry, settling, merge and game controls');
