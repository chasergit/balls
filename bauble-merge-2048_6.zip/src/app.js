import { preloadGameAssets } from './game/assets.js';
import { gameAudio } from './game/audio.js';
import { createBaublePreview } from './game/baublePreview.js';
import {
  GAME_CONFIG,
  STORAGE_KEY,
  getBoostPrice,
  getNewBallReward,
  getPreGoalMilestoneReward,
} from './game/constants.js';
import { createGameCanvas } from './game/gameCanvas.js';

function createInitialSave() {
  return {
    bestScore: 0,
    curScore: 0,
    coins: GAME_CONFIG.initialCoins,
    curMaxTier: 6,
    goalTier: GAME_CONFIG.firstGoalTier,
    spawnMinTier: 1,
    spawnMaxTier: GAME_CONFIG.spawnRangeSize,
    swapUses: GAME_CONFIG.initialSwapUses,
    shakeUses: GAME_CONFIG.initialShakeUses,
    hammerUses: GAME_CONFIG.initialHammerUses,
    sfxOn: true,
    tutorialSeen: false,
    balls: [],
  };
}

function loadSaveData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialSave();
    const parsed = JSON.parse(raw);
    const base = createInitialSave();
    return {
      ...base,
      ...parsed,
      balls: Array.isArray(parsed.balls) ? parsed.balls : [],
    };
  } catch {
    return createInitialSave();
  }
}

function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'className') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k.startsWith('on') && typeof v === 'function') {
        el.addEventListener(k.slice(2).toLowerCase(), v);
      } else {
        el.setAttribute(k, v === true ? '' : String(v));
      }
    }
  }
  for (const child of children) {
    if (child === undefined || child === null || child === false) continue;
    el.appendChild(typeof child === 'string' || typeof child === 'number' ? document.createTextNode(String(child)) : child);
  }
  return el;
}

function createTintedIcon(src, color, widthPx, heightPx, alt = '') {
  const span = document.createElement('span');
  span.className = 'tinted-icon';
  if (alt) {
    span.setAttribute('role', 'img');
    span.setAttribute('aria-label', alt);
  } else {
    span.setAttribute('aria-hidden', 'true');
  }
  span.style.width = `calc(var(--s, 1) * ${widthPx}px)`;
  span.style.height = `calc(var(--s, 1) * ${heightPx}px)`;
  span.style.backgroundColor = color;
  span.style.webkitMaskImage = `url(${src})`;
  span.style.maskImage = `url(${src})`;
  return span;
}

function setTintedIconSrc(el, src) {
  el.style.webkitMaskImage = `url(${src})`;
  el.style.maskImage = `url(${src})`;
}

function createAutoFitBoostPrice(coinSrc, initialPrice) {
  const coinEl = h('img', {
    src: coinSrc,
    alt: '',
    className: 'boost-coin-img',
  });
  const textEl = h('span', { className: 'boost-price-text' }, String(initialPrice));
  const wrapEl = h('span', { className: 'boost-price-wrap' }, coinEl, textEl);

  const fit = () => {
    const wrapW = wrapEl.clientWidth;
    const coinW = coinEl.offsetWidth;
    if (wrapW <= 0 || coinW <= 0) return;

    const baseSize = Math.min(28, Math.max(10, Math.round(wrapEl.clientHeight * 0.44)));
    textEl.style.fontSize = `${baseSize}px`;

    const avail = Math.max(8, wrapW - coinW - 4);
    const textW = textEl.scrollWidth;
    if (textW > avail) {
      let fitted = Math.max(7, Math.floor((baseSize * avail) / textW));
      textEl.style.fontSize = `${fitted}px`;
      let guard = 0;
      while (guard++ < 10 && textEl.scrollWidth > avail && fitted > 7) {
        fitted -= 1;
        textEl.style.fontSize = `${fitted}px`;
      }
    }
  };

  let ro = null;
  if (typeof ResizeObserver !== 'undefined') {
    ro = new ResizeObserver(fit);
    ro.observe(wrapEl);
  }
  requestAnimationFrame(fit);

  return {
    el: wrapEl,
    update(nextPrice) {
      const nextStr = String(nextPrice);
      if (textEl.textContent !== nextStr) {
        textEl.textContent = nextStr;
      }
      fit();
    },
    destroy() {
      if (ro) ro.disconnect();
    },
  };
}

export function mountApp(rootEl) {
  const initialSave = loadSaveData();

  const state = {
    assets: null,
    curScore: initialSave.curScore,
    bestScore: initialSave.bestScore,
    coins: initialSave.coins,
    curMaxTier: initialSave.curMaxTier,
    goalTier: initialSave.goalTier,
    spawnMinTier: initialSave.spawnMinTier,
    spawnMaxTier: initialSave.spawnMaxTier,
    swapUses: initialSave.swapUses,
    shakeUses: initialSave.shakeUses,
    hammerUses: initialSave.hammerUses,
    sfxOn: initialSave.sfxOn,
    activeBoost: null,
    showTutorial: !initialSave.tutorialSeen,
    showSettings: false,
    showNoMoves: false,
    newMaxModal: null,
    comboBanner: null,
    toastMsg: null,
    savedBalls: initialSave.balls,
  };

  gameAudio.setEnabled(state.sfxOn);

  let comboTimer = null;
  let toastTimer = null;
  let newBallTimer = null;
  let engine = null;

  function getSwapPrice() {
    return getBoostPrice(GAME_CONFIG.boostSwapBasePrice, GAME_CONFIG.boostSwapMult, state.swapUses);
  }

  function getShakePrice() {
    return getBoostPrice(GAME_CONFIG.boostShakeBasePrice, GAME_CONFIG.boostShakeMult, state.shakeUses);
  }

  function getHammerPrice() {
    return getBoostPrice(GAME_CONFIG.boostHammerBasePrice, GAME_CONFIG.boostHammerMult, state.hammerUses);
  }

  function isPaused() {
    return state.showTutorial || state.showSettings || state.showNoMoves || Boolean(state.newMaxModal);
  }

  function persistState(ballsOverride) {
    if (ballsOverride !== undefined) {
      state.savedBalls = ballsOverride;
    }
    const data = {
      bestScore: state.bestScore,
      curScore: state.curScore,
      coins: state.coins,
      curMaxTier: state.curMaxTier,
      goalTier: state.goalTier,
      spawnMinTier: state.spawnMinTier,
      spawnMaxTier: state.spawnMaxTier,
      swapUses: state.swapUses,
      shakeUses: state.shakeUses,
      hammerUses: state.hammerUses,
      sfxOn: state.sfxOn,
      tutorialSeen: !state.showTutorial,
      balls: state.savedBalls,
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      // Ignore storage quota errors
    }
  }

  let uiScale = 1;

  const fitTextElement = (el, maxPx, minPx) => {
    el.style.fontSize = '';
    const clientW = el.clientWidth;
    if (clientW <= 0 || el.scrollWidth <= clientW) return;
    let size = Math.min(maxPx, parseFloat(getComputedStyle(el).fontSize) || maxPx);
    size = Math.max(minPx, Math.floor((size * clientW) / el.scrollWidth));
    el.style.fontSize = `${size}px`;
    let guard = 0;
    while (guard++ < 10 && el.scrollWidth > clientW && size > minPx) {
      size -= 1;
      el.style.fontSize = `${size}px`;
    }
  };

  // --- Build DOM Hierarchy ---
  const bestValEl = h('span', { className: 'stat-chip-val' });
  const coinsValEl = h('span', { className: 'stat-chip-val' });
  const scoreValEl = h('div', { className: 'score-val' });
  const comboSlotEl = h('div', { className: 'score-combo-slot' });
  const goalPreview = createBaublePreview(state.goalTier, null, 52);

  const drawerIconSpan = createTintedIcon('./assets/sprites/Pictoicon_Reverse.png', '#6b87a3', 32, 32);
  const drawerTitleEl = h('div', { className: 'boost-drawer-title' });
  const drawerDescEl = h('div', { className: 'boost-drawer-desc' });
  const boostDrawerEl = h(
    'div',
    { className: 'boost-drawer is-hidden' },
    h('div', { className: 'boost-drawer-icon' }, drawerIconSpan),
    h('div', { className: 'boost-drawer-text' }, drawerTitleEl, drawerDescEl),
    h(
      'button',
      {
        type: 'button',
        className: 'btn-close-x',
        'aria-label': 'Отмена',
        onClick: () => {
          gameAudio.play('click');
          state.activeBoost = null;
          if (engine) engine.recheckMoves();
          syncUI();
        },
      },
      createTintedIcon('./assets/sprites/PictoIcon_Symbol_X.png', '#22334d', 18, 18)
    )
  );

  const topHeaderEl = h(
    'header',
    { className: 'top-panel' },
    h(
      'div',
      { className: 'top-grid' },
      h(
        'div',
        { className: 'stat-stack' },
        h(
          'div',
          { className: 'stat-chip' },
          h('img', { src: './assets/sprites/Itemicon_Crown_1.png', alt: 'Рекорд', className: 'stat-chip-icon' }),
          bestValEl
        ),
        h(
          'div',
          { className: 'stat-chip' },
          h('img', { src: './assets/sprites/Itemicon_Coin_Gold_Star.png', alt: 'Монеты', className: 'stat-chip-icon' }),
          coinsValEl
        )
      ),
      h('div', { className: 'score-pan' }, scoreValEl, comboSlotEl),
      h('div', { className: 'goal-pan' }, h('span', { className: 'goal-label' }, 'Цель'), goalPreview.el)
    ),
    boostDrawerEl
  );

  const comboBannerTitleEl = h('span', { className: 'combo-banner-title' });
  const comboBannerCoinTextEl = h('span', null);
  const comboBannerCoinsEl = h(
    'span',
    { className: 'combo-banner-coins is-hidden' },
    h('img', { src: './assets/sprites/Itemicon_Coin_Gold_Star.png', alt: '' }),
    comboBannerCoinTextEl
  );
  const comboBannerEl = h('div', { className: 'combo-banner is-hidden' }, comboBannerTitleEl, comboBannerCoinsEl);

  const toastEl = h('div', { className: 'toast-notice is-hidden' });

  const canvasEl = h('canvas', { className: 'game-canvas is-hidden' });
  const loadingBoxEl = h('div', { className: 'loading-box' }, 'Загрузка…');
  const playfieldEl = h('main', { className: 'playfield' }, loadingBoxEl, canvasEl);

  const boosterSpecs = [
    { id: 'swap', label: 'Обмен', icon: './assets/sprites/Pictoicon_Reverse.png', getPrice: getSwapPrice },
    { id: 'shake', label: 'Встряска', icon: './assets/sprites/Pictoicon_Haptic.png', getPrice: getShakePrice },
    { id: 'hammer', label: 'Молоток', icon: './assets/sprites/Pictoicon_Hammer.png', getPrice: getHammerPrice },
  ];

  const boosterControls = boosterSpecs.map((spec) => {
    const priceFit = createAutoFitBoostPrice('./assets/sprites/Itemicon_Coin_Gold_Star.png', spec.getPrice());
    const btnEl = h(
      'button',
      {
        type: 'button',
        title: spec.label,
        className: 'boost-btn',
        onClick: () => handleSelectBoost(spec.id),
      },
      h(
        'span',
        { className: 'boost-icon-badge' },
        createTintedIcon(spec.icon, '#007c69', 26, 26)
      ),
      priceFit.el
    );
    return { spec, btnEl, priceFit };
  });

  const bottomFooterEl = h(
    'footer',
    { className: 'bottom-panel' },
    h(
      'button',
      {
        type: 'button',
        title: 'Настройки',
        className: 'settings-btn',
        onClick: () => {
          void gameAudio.unlockAndPreload();
          gameAudio.play('click');
          state.showSettings = true;
          syncUI();
        },
      },
      createTintedIcon('./assets/sprites/Pictoicon_Setting.png', '#0073cc', 28, 28, 'Настройки')
    ),
    h('div', { className: 'boosters-grid' }, ...boosterControls.map((c) => c.btnEl))
  );

  // Tutorial Modal
  const tutorialModalEl = h(
    'div',
    { className: 'modal-backdrop is-hidden' },
    h(
      'div',
      { className: 'modal-card w-300' },
      h('div', { className: 'modal-header' }, h('h2', null, 'Как играть')),
      h(
        'div',
        { className: 'modal-body' },
        h(
          'div',
          { className: 'tutor-box' },
          h('img', { src: './assets/sprites/TutorPic1.png', alt: 'Обучение', className: 'tutor-pic' }),
          h('img', { src: './assets/sprites/TutorHand96.png', alt: '', className: 'tutor-hand' })
        ),
        h('p', { className: 'modal-copy' }, 'Нажимайте на шарики, чтобы объединять группы одинаковых шариков!'),
        h(
          'button',
          {
            type: 'button',
            className: 'btn-cyan',
            onClick: () => {
              void gameAudio.unlockAndPreload();
              gameAudio.play('click');
              state.showTutorial = false;
              persistState();
              syncUI();
            },
          },
          'Понятно!'
        )
      )
    )
  );

  // NewBall Modal
  const newPrevPreview = createBaublePreview(9, null, 48);
  const newMainPreview = createBaublePreview(10, null, 74);
  const newNextPreview = createBaublePreview(11, null, 48);
  const newRewardValEl = h('span', null, '+20');
  const progressRemovedPreview = createBaublePreview(1, null, 28);
  const progressAddedPreview = createBaublePreview(7, null, 28);
  const progressCardEl = h(
    'div',
    { className: 'progress-card is-hidden' },
    h('div', { className: 'progress-card-title' }, 'Прогресс!'),
    h(
      'div',
      { className: 'progress-card-row' },
      h('div', { className: 'progress-item' }, h('span', null, 'Убран:'), progressRemovedPreview.el),
      h('div', { className: 'progress-item' }, h('span', null, 'Добавлен:'), progressAddedPreview.el)
    )
  );

  const newBallModalEl = h(
    'div',
    { className: 'modal-backdrop is-hidden' },
    h(
      'div',
      { className: 'modal-card w-290' },
      h('div', { className: 'modal-header' }, h('h2', null, 'Отлично!')),
      h(
        'div',
        { className: 'modal-body' },
        h('p', { className: 'modal-copy-bold' }, 'Вы собрали новый шарик!'),
        h(
          'div',
          { className: 'new-ball-stage' },
          h('div', { className: 'new-ball-side' }, newPrevPreview.el),
          h('div', { className: 'new-ball-main' }, newMainPreview.el),
          h('div', { className: 'new-ball-side' }, newNextPreview.el)
        ),
        h(
          'div',
          { className: 'reward-pill' },
          h('img', { src: './assets/sprites/Itemicon_Coin_Gold_Star.png', alt: 'Монеты' }),
          newRewardValEl
        ),
        progressCardEl,
        h(
          'button',
          {
            type: 'button',
            className: 'btn-cyan',
            onClick: () => {
              gameAudio.play('click');
              if (state.newMaxModal && state.newMaxModal.reward > 0) {
                state.coins += state.newMaxModal.reward;
                gameAudio.play('coinPop');
              }
              state.newMaxModal = null;
              persistState();
              syncUI();
            },
          },
          'Получить'
        )
      )
    )
  );

  // Settings Modal
  const soundIconEl = createTintedIcon(
    state.sfxOn ? './assets/sprites/Pictoicon_Volume_On.png' : './assets/sprites/Pictoicon_Volume_Mute.png',
    '#0073cc',
    24,
    24
  );
  const soundToggleBtnEl = h(
    'button',
    {
      type: 'button',
      className: 'btn-cyan icon-only',
      onClick: () => {
        void gameAudio.unlockAndPreload();
        state.sfxOn = !state.sfxOn;
        gameAudio.setEnabled(state.sfxOn);
        if (state.sfxOn) {
          gameAudio.play('click');
        }
        persistState();
        syncUI();
      },
    },
    soundIconEl
  );

  const settingsModalEl = h(
    'div',
    { className: 'modal-backdrop is-hidden' },
    h(
      'div',
      { className: 'modal-card w-260' },
      h(
        'div',
        { className: 'modal-header has-close' },
        h('h2', null, 'Настройки'),
        h(
          'button',
          {
            type: 'button',
            className: 'btn-close-x modal-close-abs',
            'aria-label': 'Закрыть',
            onClick: () => {
              gameAudio.play('click');
              state.showSettings = false;
              syncUI();
            },
          },
          createTintedIcon('./assets/sprites/PictoIcon_Symbol_X.png', '#22334d', 14, 14)
        )
      ),
      h(
        'div',
        { className: 'modal-body' },
        h(
          'div',
          { className: 'settings-row' },
          soundToggleBtnEl,
          h(
            'button',
            {
              type: 'button',
              className: 'btn-cyan compact',
              onClick: () => {
                gameAudio.play('click');
                state.showSettings = false;
                state.showTutorial = true;
                persistState();
                syncUI();
              },
            },
            'Как играть'
          )
        ),
        h(
          'button',
          {
            type: 'button',
            className: 'btn-amber',
            onClick: handleRestart,
          },
          createTintedIcon('./assets/sprites/Pictoicon_Refresh.png', '#ff5c5c', 24, 24),
          h('span', null, 'Заново')
        ),
        h(
          'button',
          {
            type: 'button',
            className: 'btn-cyan narrow',
            onClick: () => {
              gameAudio.play('click');
              state.showSettings = false;
              syncUI();
            },
          },
          'Закрыть'
        )
      )
    )
  );

  // GameOver Modal
  const goScoreValEl = h('div', { className: 'gameover-val' });
  const goBestValEl = h('span', { className: 'gameover-val' });
  const goShakePriceEl = h('span', null);
  const goShakeBtnEl = h(
    'button',
    {
      type: 'button',
      className: 'btn-green-wide',
      onClick: () => handleSelectBoost('shake'),
    },
    h(
      'span',
      { className: 'btn-green-left' },
      createTintedIcon('./assets/sprites/Pictoicon_Haptic.png', '#007c69', 24, 24),
      h('span', null, 'Встряска')
    ),
    h(
      'span',
      { className: 'btn-green-right' },
      h('img', { src: './assets/sprites/Itemicon_Coin_Gold_Star.png', alt: '' }),
      goShakePriceEl
    )
  );
  const goSwapPriceEl = h('span', null);
  const goSwapBtnEl = h(
    'button',
    {
      type: 'button',
      className: 'btn-green-wide',
      onClick: () => handleSelectBoost('swap'),
    },
    h(
      'span',
      { className: 'btn-green-left' },
      createTintedIcon('./assets/sprites/Pictoicon_Reverse.png', '#007c69', 24, 24),
      h('span', null, 'Обмен')
    ),
    h(
      'span',
      { className: 'btn-green-right' },
      h('img', { src: './assets/sprites/Itemicon_Coin_Gold_Star.png', alt: '' }),
      goSwapPriceEl
    )
  );

  const gameOverModalEl = h(
    'div',
    { className: 'modal-backdrop is-hidden' },
    h(
      'div',
      { className: 'modal-card w-270' },
      h('div', { className: 'modal-header' }, h('h2', null, 'Нет ходов!')),
      h(
        'div',
        { className: 'modal-body' },
        h(
          'div',
          { className: 'gameover-scores' },
          h('div', null, h('div', { className: 'gameover-label' }, 'Счёт'), goScoreValEl),
          h('div', { className: 'gameover-divider' }),
          h(
            'div',
            null,
            h('div', { className: 'gameover-label' }, 'Рекорд'),
            h(
              'div',
              { className: 'gameover-best-row' },
              h('img', { src: './assets/sprites/Itemicon_Crown_1.png', alt: '' }),
              goBestValEl
            )
          )
        ),
        h(
          'div',
          { className: 'gameover-actions' },
          goShakeBtnEl,
          goSwapBtnEl,
          h(
            'button',
            {
              type: 'button',
              className: 'btn-cyan',
              onClick: handleRestart,
            },
            'Заново'
          )
        )
      )
    )
  );

  const cabinetEl = h(
    'div',
    { className: 'cabinet' },
    topHeaderEl,
    comboBannerEl,
    toastEl,
    playfieldEl,
    bottomFooterEl,
    tutorialModalEl,
    newBallModalEl,
    settingsModalEl,
    gameOverModalEl
  );
  const backdropEl = h('div', { className: 'app-backdrop' }, cabinetEl);

  rootEl.replaceChildren(backdropEl);

  function updateCabinetScale() {
    const cabW =
      cabinetEl.clientWidth || Math.min(window.innerWidth, (window.innerHeight * 9) / 16);
    const cabH = cabinetEl.clientHeight || window.innerHeight;
    uiScale = Math.max(0.42, Math.min(1.4, Math.min(cabW / 460, cabH / 760)));
    cabinetEl.style.setProperty('--s', uiScale.toFixed(4));
  }

  updateCabinetScale();

  // --- Handlers & Sync ---
  function showNotice(msg) {
    if (toastTimer !== null) {
      window.clearTimeout(toastTimer);
    }
    state.toastMsg = msg;
    syncUI();
    toastTimer = window.setTimeout(() => {
      state.toastMsg = null;
      toastTimer = null;
      syncUI();
    }, 2400);
  }

  function handleSelectBoost(boost) {
    void gameAudio.unlockAndPreload();
    gameAudio.play('click');

    if (state.activeBoost === boost) {
      state.activeBoost = null;
      if (engine) engine.recheckMoves();
      syncUI();
      return;
    }

    const price =
      boost === 'swap' ? getSwapPrice() : boost === 'shake' ? getShakePrice() : getHammerPrice();

    if (state.coins < price) {
      showNotice('Недостаточно монет!');
      return;
    }

    if (boost === 'shake') {
      state.coins = Math.max(0, state.coins - price);
      state.shakeUses += 1;
      state.activeBoost = null;
      state.showNoMoves = false;
      persistState();
      syncUI();
      if (engine) engine.triggerShake();
      return;
    }

    state.showNoMoves = false;
    state.activeBoost = boost;
    syncUI();
  }

  function handleBoostConsumed(boost) {
    if (boost === 'swap') {
      state.coins = Math.max(0, state.coins - getSwapPrice());
      state.swapUses += 1;
    } else if (boost === 'hammer') {
      state.coins = Math.max(0, state.coins - getHammerPrice());
      state.hammerUses += 1;
    }
    state.activeBoost = null;
    persistState();
    syncUI();
  }

  function handleMerge(outcome) {
    state.curScore += outcome.scoreAdded;
    if (state.curScore > state.bestScore) {
      state.bestScore = state.curScore;
    }

    const comboCoins = outcome.comboCoins || 0;
    let milestoneCoins = 0;

    if (outcome.isCombo) {
      const tier =
        outcome.count >= GAME_CONFIG.comboHighSize
          ? 3
          : outcome.count >= GAME_CONFIG.comboMidSize
            ? 2
            : 1;
      const text =
        tier === 3
          ? `СУПЕР КОМБО x${outcome.count} !!!`
          : tier === 2
            ? `Потрясающее комбо x${outcome.count}!`
            : `Отличное комбо x${outcome.count}!`;

      if (comboTimer !== null) {
        window.clearTimeout(comboTimer);
      }
      state.comboBanner = {
        key: Date.now(),
        count: outcome.count,
        text,
        tier,
        coins: comboCoins,
      };
      // Restart CSS pop animation cleanly
      comboBannerEl.style.animation = 'none';
      void comboBannerEl.offsetWidth;
      comboBannerEl.style.animation = '';

      comboTimer = window.setTimeout(() => {
        state.comboBanner = null;
        comboTimer = null;
        syncUI();
      }, 1650);
    }

    if (outcome.newTier > state.curMaxTier) {
      const newMax = outcome.newTier;
      const prevMax = state.curMaxTier;
      state.curMaxTier = newMax;

      if (newMax >= state.goalTier) {
        state.goalTier = newMax + 1;
      }

      let removedTier;
      let addedTier;
      if (
        newMax >= GAME_CONFIG.firstSpawnRangeChangeTier &&
        (newMax - GAME_CONFIG.firstSpawnRangeChangeTier) % GAME_CONFIG.spawnRangeChangeStep === 0
      ) {
        const nextMin = state.spawnMinTier + 1;
        const nextMax = state.spawnMaxTier + 1;
        if (nextMax <= 26) {
          removedTier = state.spawnMinTier;
          addedTier = nextMax;
          state.spawnMinTier = nextMin;
          state.spawnMaxTier = nextMax;
          if (engine) engine.shiftSpawnRange(nextMin, nextMax);
        }
      }

      if (newMax >= GAME_CONFIG.firstGoalTier) {
        const steps = newMax - Math.max(prevMax, GAME_CONFIG.firstGoalTier - 1);
        const reward = getNewBallReward(newMax, steps);
        if (newBallTimer !== null) {
          window.clearTimeout(newBallTimer);
        }
        newBallTimer = window.setTimeout(() => {
          newBallTimer = null;
          gameAudio.play('newMaxWindow');
          state.newMaxModal = state.newMaxModal
            ? {
                tier: Math.max(state.newMaxModal.tier, newMax),
                reward: state.newMaxModal.reward + reward,
                removedTier: removedTier ?? state.newMaxModal.removedTier,
                addedTier: addedTier ?? state.newMaxModal.addedTier,
              }
            : {
                tier: newMax,
                reward,
                removedTier,
                addedTier,
              };
          syncUI();
        }, Math.round(GAME_CONFIG.newBallWaitTime * 1000));
      } else {
        milestoneCoins = getPreGoalMilestoneReward(newMax);
      }
    }

    const immediateCoins = comboCoins + milestoneCoins;
    if (immediateCoins > 0) {
      state.coins += immediateCoins;
      gameAudio.play('coinPop');
    }

    persistState();
    syncUI();
  }

  function handleRestart() {
    void gameAudio.unlockAndPreload();
    gameAudio.play('click');
    if (newBallTimer !== null) {
      window.clearTimeout(newBallTimer);
      newBallTimer = null;
    }
    if (comboTimer !== null) {
      window.clearTimeout(comboTimer);
      comboTimer = null;
    }
    state.curScore = 0;
    state.curMaxTier = 6;
    state.goalTier = GAME_CONFIG.firstGoalTier;
    state.spawnMinTier = 1;
    state.spawnMaxTier = GAME_CONFIG.spawnRangeSize;
    state.swapUses = 0;
    state.shakeUses = 0;
    state.hammerUses = 0;
    state.activeBoost = null;
    state.showNoMoves = false;
    state.showSettings = false;
    state.newMaxModal = null;
    state.comboBanner = null;
    if (engine) engine.resetBoard(1, GAME_CONFIG.spawnRangeSize);
    persistState();
    syncUI();
  }

  function syncTopFit() {
    const goalSz = Math.max(20, Math.round(52 * uiScale));
    goalPreview.update(state.goalTier, state.assets, goalSz);
    fitTextElement(
      bestValEl,
      Math.max(10, Math.round(20 * uiScale)),
      Math.max(8, Math.round(10 * uiScale))
    );
    fitTextElement(
      coinsValEl,
      Math.max(10, Math.round(20 * uiScale)),
      Math.max(8, Math.round(10 * uiScale))
    );
    fitTextElement(
      scoreValEl,
      Math.max(14, Math.round(36 * uiScale)),
      Math.max(10, Math.round(14 * uiScale))
    );
  }

  function syncUI() {
    bestValEl.textContent = state.bestScore.toLocaleString('ru-RU');
    coinsValEl.textContent = state.coins.toLocaleString('ru-RU');
    scoreValEl.textContent = state.curScore.toLocaleString('ru-RU');
    syncTopFit();

    if (state.comboBanner) {
      comboSlotEl.innerHTML = `Комбо<br />×${state.comboBanner.count}`;
      comboBannerEl.classList.remove('is-hidden');
      comboBannerTitleEl.textContent = state.comboBanner.text;
      comboBannerTitleEl.className = `combo-banner-title${
        state.comboBanner.tier === 3
          ? ' tier-3'
          : state.comboBanner.tier === 2
            ? ' tier-2'
            : ''
      }`;
      if (state.comboBanner.coins > 0) {
        comboBannerCoinsEl.classList.remove('is-hidden');
        comboBannerCoinTextEl.textContent = `+${state.comboBanner.coins}`;
      } else {
        comboBannerCoinsEl.classList.add('is-hidden');
      }
    } else {
      comboSlotEl.textContent = '';
      comboBannerEl.classList.add('is-hidden');
    }

    if (state.toastMsg) {
      toastEl.textContent = state.toastMsg;
      toastEl.classList.remove('is-hidden');
    } else {
      toastEl.classList.add('is-hidden');
    }

    if (state.activeBoost) {
      boostDrawerEl.classList.remove('is-hidden');
      setTintedIconSrc(
        drawerIconSpan,
        state.activeBoost === 'swap'
          ? './assets/sprites/Pictoicon_Reverse.png'
          : './assets/sprites/Pictoicon_Hammer.png'
      );
      drawerTitleEl.textContent = state.activeBoost === 'swap' ? 'Обмен шариков' : 'Молоток';
      drawerDescEl.textContent =
        state.activeBoost === 'swap'
          ? 'Выберите два шарика, чтобы поменять их местами.'
          : 'Нажмите на шарик, чтобы убрать его с поля.';
    } else {
      boostDrawerEl.classList.add('is-hidden');
    }

    for (let i = 0; i < boosterControls.length; i++) {
      const { spec, btnEl, priceFit } = boosterControls[i];
      const price = spec.getPrice();
      const isSelected = state.activeBoost === spec.id;
      const canAfford = state.coins >= price;

      btnEl.classList.toggle('is-selected', isSelected);
      btnEl.classList.toggle('is-unaffordable', !isSelected && !canAfford);
      priceFit.update(price);
    }

    tutorialModalEl.classList.toggle('is-hidden', !state.showTutorial);

    settingsModalEl.classList.toggle('is-hidden', !state.showSettings);
    soundToggleBtnEl.title = state.sfxOn ? 'Выключить звук' : 'Включить звук';
    setTintedIconSrc(
      soundIconEl,
      state.sfxOn
        ? './assets/sprites/Pictoicon_Volume_On.png'
        : './assets/sprites/Pictoicon_Volume_Mute.png'
    );

    if (state.newMaxModal) {
      const m = state.newMaxModal;
      const sideSz = Math.max(22, Math.round(48 * uiScale));
      const mainSz = Math.max(34, Math.round(74 * uiScale));
      const progSz = Math.max(14, Math.round(28 * uiScale));
      newBallModalEl.classList.remove('is-hidden');
      newPrevPreview.update(Math.max(1, m.tier - 1), state.assets, sideSz);
      newMainPreview.update(m.tier, state.assets, mainSz);
      newNextPreview.update(Math.min(30, m.tier + 1), state.assets, sideSz);
      newRewardValEl.textContent = `+${m.reward}`;
      if (m.removedTier && m.addedTier) {
        progressCardEl.classList.remove('is-hidden');
        progressRemovedPreview.update(m.removedTier, state.assets, progSz);
        progressAddedPreview.update(m.addedTier, state.assets, progSz);
      } else {
        progressCardEl.classList.add('is-hidden');
      }
    } else {
      newBallModalEl.classList.add('is-hidden');
    }

    if (state.showNoMoves) {
      const shakeP = getShakePrice();
      const swapP = getSwapPrice();
      gameOverModalEl.classList.remove('is-hidden');
      goScoreValEl.textContent = state.curScore.toLocaleString('ru-RU');
      goBestValEl.textContent = state.bestScore.toLocaleString('ru-RU');
      goShakeBtnEl.classList.toggle('is-hidden', state.coins < shakeP);
      goShakePriceEl.textContent = String(shakeP);
      goSwapBtnEl.classList.toggle('is-hidden', state.coins < swapP);
      goSwapPriceEl.textContent = String(swapP);
    } else {
      gameOverModalEl.classList.add('is-hidden');
    }

    if (engine) {
      engine.updateOptions({
        assets: state.assets,
        spawnMinTier: state.spawnMinTier,
        spawnMaxTier: state.spawnMaxTier,
        curMaxTier: state.curMaxTier,
        activeBoost: state.activeBoost,
        paused: isPaused(),
      });
    }
  }

  syncUI();

  let destroyed = false;
  void preloadGameAssets().then((loadedAssets) => {
    if (destroyed) return;
    state.assets = loadedAssets;
    loadingBoxEl.classList.add('is-hidden');
    canvasEl.classList.remove('is-hidden');

    engine = createGameCanvas(
      canvasEl,
      {
        assets: state.assets,
        initialSavedBalls: state.savedBalls,
        spawnMinTier: state.spawnMinTier,
        spawnMaxTier: state.spawnMaxTier,
        curMaxTier: state.curMaxTier,
        activeBoost: state.activeBoost,
        paused: isPaused(),
      },
      {
        onMerge: handleMerge,
        onBoostConsumed: handleBoostConsumed,
        onNoMoves: () => {
          gameAudio.play('lose');
          state.showNoMoves = true;
          syncUI();
        },
        onBoardChanged: (balls) => {
          persistState(balls);
        },
      }
    );

    syncUI();
  });

  const handleResize = () => {
    updateCabinetScale();
    syncTopFit();
    if (state.newMaxModal) {
      const m = state.newMaxModal;
      const sideSz = Math.max(22, Math.round(48 * uiScale));
      const mainSz = Math.max(34, Math.round(74 * uiScale));
      const progSz = Math.max(14, Math.round(28 * uiScale));
      newPrevPreview.update(Math.max(1, m.tier - 1), state.assets, sideSz);
      newMainPreview.update(m.tier, state.assets, mainSz);
      newNextPreview.update(Math.min(30, m.tier + 1), state.assets, sideSz);
      if (m.removedTier && m.addedTier) {
        progressRemovedPreview.update(m.removedTier, state.assets, progSz);
        progressAddedPreview.update(m.addedTier, state.assets, progSz);
      }
    }
  };

  let cabinetRo = null;
  if (typeof ResizeObserver !== 'undefined') {
    cabinetRo = new ResizeObserver(handleResize);
    cabinetRo.observe(cabinetEl);
  }
  window.addEventListener('resize', handleResize);
  requestAnimationFrame(handleResize);

  return () => {
    destroyed = true;
    if (cabinetRo) cabinetRo.disconnect();
    window.removeEventListener('resize', handleResize);
    if (comboTimer !== null) window.clearTimeout(comboTimer);
    if (toastTimer !== null) window.clearTimeout(toastTimer);
    if (newBallTimer !== null) window.clearTimeout(newBallTimer);
    if (engine) engine.destroy();
    for (let i = 0; i < boosterControls.length; i++) {
      boosterControls[i].priceFit.destroy();
    }
  };
}
