import { mountApp } from './app.js';

const rootEl = document.getElementById('root');
if (rootEl) {
  mountApp(rootEl);
}
