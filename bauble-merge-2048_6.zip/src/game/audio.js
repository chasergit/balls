const SOUND_SPECS = {
  mergePath: {
    url: './assets/audio/SFX_Bell_Chime_Oneshot_Low_To_High_Short_3.m4a',
    volume: 0.5,
    pitchMin: 1.0,
    pitchMax: 1.2,
  },
  merge: {
    url: './assets/audio/SFX_UI_Fillup_Coin_3.m4a',
    volume: 0.7,
    pitchMin: 0.8,
    pitchMax: 1.2,
  },
  mergeCombo: {
    url: './assets/audio/SFX_UI_Fillup_Star_Pop_1.m4a',
    volume: 1.0,
    pitchMin: 0.8,
    pitchMax: 1.2,
  },
  mergeNew: {
    url: './assets/audio/SFX_UI_Fillup_Star_Bright_1.m4a',
    volume: 1.0,
    pitchMin: 0.8,
    pitchMax: 1.2,
  },
  newMaxWindow: {
    url: './assets/audio/SFX_UI_Success_Pop_Cute_1.m4a',
    volume: 1.0,
    pitchMin: 1.0,
    pitchMax: 1.0,
  },
  coinPop: {
    url: './assets/audio/SFX_UI_Fillup_Coin_2.m4a',
    volume: 1.0,
    pitchMin: 1.0,
    pitchMax: 1.0,
  },
  remove: {
    url: './assets/audio/SFX_UI_Click_Generic_1.m4a',
    volume: 1.0,
    pitchMin: 0.8,
    pitchMax: 1.2,
  },
  shake: {
    url: './assets/audio/SFX_Bell_Sleigh_Oneshot_Short_1.m4a',
    volume: 1.0,
    pitchMin: 0.8,
    pitchMax: 1.2,
  },
  lose: {
    url: './assets/audio/SFX_UI_Notification_2.m4a',
    volume: 1.0,
    pitchMin: 1.0,
    pitchMax: 1.0,
  },
  click: {
    url: './assets/audio/Clicks Sound (button hover) 3.m4a',
    volume: 1.0,
    pitchMin: 0.8,
    pitchMax: 1.2,
  },
};

class GameAudioEngine {
  constructor() {
    this.ctx = null;
    this.buffers = new Map();
    this.loadingPromise = null;
    this.enabled = true;
    this.lastPlayed = new Map();
  }

  setEnabled(on) {
    this.enabled = on;
  }

  async unlockAndPreload() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      await this.ctx.resume().catch(() => undefined);
    }
    if (!this.loadingPromise) {
      this.loadingPromise = this.preloadAll();
    }
    await this.loadingPromise;
  }

  async preloadAll() {
    if (!this.ctx) return;
    const entries = Object.entries(SOUND_SPECS);
    await Promise.all(
      entries.map(async ([key, spec]) => {
        try {
          const res = await fetch(encodeURI(spec.url));
          if (!res.ok) return;
          const arr = await res.arrayBuffer();
          const decoded = await this.ctx.decodeAudioData(arr);
          this.buffers.set(key, decoded);
        } catch {
          // Ignore decode failures cleanly
        }
      })
    );
  }

  play(key, pitchOverride) {
    if (!this.enabled) return;
    const nowMs = performance.now();
    const prev = this.lastPlayed.get(key) ?? 0;
    if (nowMs - prev < 100) return;
    this.lastPlayed.set(key, nowMs);

    if (!this.ctx) {
      void this.unlockAndPreload();
      return;
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    const buffer = this.buffers.get(key);
    if (!buffer) return;

    const spec = SOUND_SPECS[key];
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;

    const pitch =
      pitchOverride ??
      (spec.pitchMin === spec.pitchMax
        ? spec.pitchMin
        : spec.pitchMin + Math.random() * (spec.pitchMax - spec.pitchMin));
    source.playbackRate.value = pitch;

    const gain = this.ctx.createGain();
    gain.gain.value = spec.volume;

    source.connect(gain);
    gain.connect(this.ctx.destination);
    source.start();
  }
}

export const gameAudio = new GameAudioEngine();
