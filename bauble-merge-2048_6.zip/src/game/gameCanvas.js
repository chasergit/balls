import { gameAudio } from './audio.js';
import {
  calcComboCoins,
  calcScoreForMove,
  GAME_CONFIG,
  getPreGoalMilestoneReward,
  getTierConfig,
} from './constants.js';
import {
  PhysicsPit,
  allocEntityId,
  buildMergeTree,
  findLargestAvailableMerge,
} from './physics.js';

const FONT_CACHE = new Map();
function getBallFont(fontSize) {
  let font = FONT_CACHE.get(fontSize);
  if (!font) {
    font = `700 ${fontSize}px "Fredoka", "Plus Jakarta Sans", sans-serif`;
    FONT_CACHE.set(fontSize, font);
  }
  return font;
}

export function createGameCanvas(canvas, initialState, callbacks) {
  const cleanSaved = Array.isArray(initialState.initialSavedBalls)
    ? initialState.initialSavedBalls.filter((b) => b && b.y <= 8.8).slice(0, 66)
    : [];

  const pit = new PhysicsPit(cleanSaved, initialState.spawnMinTier, initialState.spawnMaxTier);

  const state = {
    assets: initialState.assets,
    spawnMinTier: initialState.spawnMinTier,
    spawnMaxTier: initialState.spawnMaxTier,
    curMaxTier: initialState.curMaxTier,
    activeBoost: initialState.activeBoost,
    paused: initialState.paused,
  };

  const particles = [];
  const texts = [];
  const completedMerges = [];
  const highlightedIds = new Set();
  const pointerWorld = { x: 0, y: 0, active: false };

  let hoveredBallId = null;
  let swapFirstId = null;
  let hintGroup = null;
  let idleTimer = 0;
  let noMovesTriggered = false;
  let stillFrames = 0;
  let screenShake = 0;
  let rafId = 0;
  let lastTime = performance.now();

  if (pit.balls.length === 0) {
    pit.fillPitBalls(state.spawnMinTier, state.spawnMaxTier);
    callbacks.onBoardChanged(pit.serializeBalls());
  }

  function spawnBurstParticles(x, y, color, count, withRipple) {
    if (withRipple) {
      particles.push({
        kind: 'ripple',
        x,
        y,
        vx: 0,
        vy: 0,
        size: 0.4,
        life: 0,
        maxLife: 0.45,
        rotation: 0,
        vRot: 0,
        color,
      });
    }
    for (let i = 0; i < count; i++) {
      const ang = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.4;
      const spd = 1.4 + Math.random() * 2.4;
      particles.push({
        kind: 'star',
        x,
        y,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd,
        size: 0.24 + Math.random() * 0.22,
        life: 0,
        maxLife: 0.45 + Math.random() * 0.25,
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 8,
        color,
      });
    }
  }

  function getLayoutMetrics(width, height) {
    const padX = Math.max(2, Math.min(6, width * 0.012));
    const padY = Math.max(2, Math.min(6, height * 0.01));
    const availW = Math.max(40, width - padX * 2);
    const availH = Math.max(40, height - padY * 2);
    const aspect = GAME_CONFIG.fieldWidth / GAME_CONFIG.fieldHeight;

    let boxW = availW;
    let boxH = boxW / aspect;
    if (boxH > availH) {
      boxH = availH;
      boxW = boxH * aspect;
    }

    const boxX = (width - boxW) * 0.5;
    const boxY = (height - boxH) * 0.5;
    const pxPerUnit = boxW / GAME_CONFIG.fieldWidth;
    const originX = boxX + boxW * 0.5;
    const originY = boxY + boxH;

    return { boxX, boxY, boxW, boxH, pxPerUnit, originX, originY };
  }

  function clientToWorld(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    const cx = clientX - rect.left;
    const cy = clientY - rect.top;
    const m = getLayoutMetrics(rect.width, rect.height);
    const wx = (cx - m.originX) / m.pxPerUnit;
    const wy = (m.originY - cy) / m.pxPerUnit;
    return { wx, wy };
  }

  function findBallAt(wx, wy) {
    let best = null;
    let bestDistSq = Infinity;
    for (let i = 0; i < pit.balls.length; i++) {
      const b = pit.balls[i];
      if (b.lockedForMerge) continue;
      const dx = b.x - wx;
      const dy = b.y - wy;
      const dSq = dx * dx + dy * dy;
      const hitR = b.radius * 1.12;
      if (dSq <= hitR * hitR && dSq < bestDistSq) {
        best = b;
        bestDistSq = dSq;
      }
    }
    return best;
  }

  function handlePointerMove(e) {
    const pos = clientToWorld(e.clientX, e.clientY);
    pointerWorld.x = pos.wx;
    pointerWorld.y = pos.wy;
    pointerWorld.active = true;
  }

  function handlePointerLeave() {
    pointerWorld.active = false;
    hoveredBallId = null;
  }

  function handlePointerDown(e) {
    void gameAudio.unlockAndPreload();
    if (state.paused) return;

    const pos = clientToWorld(e.clientX, e.clientY);
    pointerWorld.x = pos.wx;
    pointerWorld.y = pos.wy;
    pointerWorld.active = true;

    const hit = findBallAt(pos.wx, pos.wy);
    if (!hit) return;

    idleTimer = 0;
    hintGroup = null;

    const boost = state.activeBoost;

    // 1. Hammer Boost
    if (boost === 'hammer') {
      gameAudio.play('remove');
      const cfg = getTierConfig(hit.tier);
      spawnBurstParticles(hit.x, hit.y, cfg.color, 12, true);
      pit.removeBall(hit.id);
      pit.fillPitBalls(state.spawnMinTier, state.spawnMaxTier);

      noMovesTriggered = false;
      stillFrames = 0;
      callbacks.onBoostConsumed('hammer');
      callbacks.onBoardChanged(pit.serializeBalls());
      return;
    }

    // 2. Swap Boost
    if (boost === 'swap') {
      if (swapFirstId === null) {
        swapFirstId = hit.id;
        hit.shakeTimer = 0.25;
        hit.shakeAmp = 0.03;
        gameAudio.play('click');
        return;
      }
      if (swapFirstId === hit.id) {
        swapFirstId = null;
        gameAudio.play('click');
        return;
      }

      const firstBall = pit.ballById.get(swapFirstId);
      if (!firstBall || firstBall.lockedForMerge) {
        swapFirstId = hit.id;
        return;
      }

      if (pit.swapBallTiers(firstBall.id, hit.id)) {
        spawnBurstParticles(firstBall.x, firstBall.y, getTierConfig(firstBall.tier).color, 6, false);
        spawnBurstParticles(hit.x, hit.y, getTierConfig(hit.tier).color, 6, false);
        gameAudio.play('merge');
      }

      swapFirstId = null;
      noMovesTriggered = false;
      stillFrames = 0;
      callbacks.onBoostConsumed('swap');
      callbacks.onBoardChanged(pit.serializeBalls());
      return;
    }

    // 3. Normal Merge Tap
    const tree = buildMergeTree(pit.balls, hit.id);
    if (!tree || tree.balls.length < 2) {
      hit.shakeTimer = 0.18;
      hit.shakeAmp = 0.025;
      gameAudio.play('click', 0.9);
      return;
    }

    const rootId = hit.id;
    const count = tree.balls.length;
    const oldTier = hit.tier;
    const stepsUp = Math.floor(Math.log2(count));
    const newTier = Math.min(30, oldTier + stepsUp);
    const isCombo = count >= GAME_CONFIG.comboMinSize;
    const isNewMax = newTier > state.curMaxTier;

    gameAudio.play('mergePath');

    pit.startMerge(rootId, tree.balls, GAME_CONFIG.mergeTime, {
      oldTier,
      newTier,
      count,
      isCombo,
      isNewMax,
    });
    noMovesTriggered = false;
    stillFrames = 0;
  }

  function drawBallSpriteAndText(ctx, curAssets, tier, cx, cy, rPx, angle, scale) {
    const cfg = getTierConfig(tier);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-angle);
    ctx.scale(scale, scale);

    const spriteDrawSize = rPx * cfg.scale * 1.28;
    const offX = cfg.shiftX * rPx;
    const offY = -cfg.shiftY * rPx;

    const rawImg = curAssets && curAssets.rawBalls ? curAssets.rawBalls.get(tier) : null;
    if (rawImg) {
      ctx.drawImage(
        rawImg,
        -spriteDrawSize * 0.5 + offX,
        -spriteDrawSize * 0.5 + offY,
        spriteDrawSize,
        spriteDrawSize
      );
    } else {
      ctx.beginPath();
      ctx.arc(0, 0, rPx, 0, Math.PI * 2);
      ctx.fillStyle = cfg.color;
      ctx.fill();
    }

    const label = cfg.label;
    const fontScale =
      label.length <= 1
        ? 0.96
        : label.length === 2
          ? 0.84
          : label.length === 3
            ? 0.68
            : 0.54;
    const fontSize = Math.max(7, Math.round(rPx * fontScale));
    ctx.font = getBallFont(fontSize);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(1.5, fontSize * 0.17);
    ctx.strokeStyle = GAME_CONFIG.ballNumberOutlineColor;
    ctx.strokeText(label, 0, 0);
    ctx.fillStyle = GAME_CONFIG.ballNumberFaceColor;
    ctx.fillText(label, 0, 0);
    ctx.restore();
  }

  function finalizeCompletedMerge(pm) {
    const target = pit.setBallTier(pm.rootId, pm.newTier);
    if (!target) return;

    target.lockedForMerge = false;
    target.scaleAnim = 0.45;

    const cfg = getTierConfig(pm.newTier);
    spawnBurstParticles(target.x, target.y, cfg.color, pm.isCombo ? 16 : 9, true);

    const scoreAdded = calcScoreForMove(pm.oldTier, pm.count);
    const isNowNewMax = pm.isNewMax || pm.newTier > state.curMaxTier;
    const comboCoins = calcComboCoins(pm.count);
    const milestoneCoins = isNowNewMax ? getPreGoalMilestoneReward(pm.newTier) : 0;
    const coinsEarned = comboCoins + milestoneCoins;

    texts.push({
      id: allocEntityId(),
      text: `+${scoreAdded.toLocaleString('ru-RU')}`,
      x: target.x,
      y: Math.min(GAME_CONFIG.fieldHeight - 0.65, target.y + target.radius + 0.25),
      vy: 1.15,
      life: 0,
      maxLife: pm.isCombo ? 1.15 : 0.9,
      scale: pm.isCombo ? 1.2 : 1.0,
      hasCoin: false,
    });

    if (coinsEarned > 0) {
      texts.push({
        id: allocEntityId(),
        text: `+${coinsEarned}`,
        x: target.x,
        y: Math.min(GAME_CONFIG.fieldHeight - 0.35, target.y + target.radius + 0.72),
        vy: 1.25,
        life: 0,
        maxLife: 1.25,
        scale: 1.08,
        hasCoin: true,
      });
    }

    if (pm.isCombo) {
      gameAudio.play('mergeCombo');
      if (isNowNewMax) {
        gameAudio.play('mergeNew');
      }
      screenShake = 0.25;
    } else if (isNowNewMax) {
      gameAudio.play('mergeNew');
    } else {
      gameAudio.play('merge');
    }

    pit.fillPitBalls(state.spawnMinTier, state.spawnMaxTier);

    callbacks.onMerge({
      count: pm.count,
      oldTier: pm.oldTier,
      newTier: pm.newTier,
      scoreAdded,
      comboCoins,
      isCombo: pm.isCombo,
      isNewMax: isNowNewMax,
    });
    callbacks.onBoardChanged(pit.serializeBalls());
  }

  function loop(now) {
    const dt = Math.min(0.05, Math.max(0.001, (now - lastTime) / 1000));
    lastTime = now;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = canvas.getBoundingClientRect();
    const targetW = Math.round(rect.width * dpr);
    const targetH = Math.round(rect.height * dpr);
    if (targetW > 0 && targetH > 0 && (canvas.width !== targetW || canvas.height !== targetH)) {
      canvas.width = targetW;
      canvas.height = targetH;
    }

    const ctx = canvas.getContext('2d');
    if (ctx && rect.width > 0 && rect.height > 0) {
      const curAssets = state.assets;
      const curBoost = state.activeBoost;
      const isPaused = state.paused;
      const maxTier = state.curMaxTier;

      if (!isPaused) {
        completedMerges.length = 0;
        pit.step(dt, completedMerges);
        for (let i = 0; i < completedMerges.length; i++) {
          finalizeCompletedMerge(completedMerges[i]);
        }

        if (pointerWorld.active && curBoost) {
          const hit = findBallAt(pointerWorld.x, pointerWorld.y);
          hoveredBallId = hit ? hit.id : null;
        } else {
          hoveredBallId = null;
        }

        if (pit.isSettled()) {
          stillFrames++;
          idleTimer += dt;
          if (stillFrames === 20 && !noMovesTriggered) {
            const avail = findLargestAvailableMerge(pit.balls);
            if (!avail) {
              noMovesTriggered = true;
              callbacks.onNoMoves();
            }
          }
          if (idleTimer >= GAME_CONFIG.hintDelaySec && !hintGroup) {
            hintGroup = findLargestAvailableMerge(pit.balls);
          }
        } else {
          stillFrames = 0;
          idleTimer = 0;
        }
      }

      // In-place particle compaction
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.life += dt;
        if (p.life >= p.maxLife) {
          particles[i] = particles[particles.length - 1];
          particles.pop();
          continue;
        }
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vx *= 0.94;
        p.vy *= 0.94;
        p.rotation += p.vRot * dt;
      }

      // In-place floating text compaction
      for (let i = texts.length - 1; i >= 0; i--) {
        const ft = texts[i];
        ft.life += dt;
        if (ft.life >= ft.maxLife) {
          texts[i] = texts[texts.length - 1];
          texts.pop();
          continue;
        }
        ft.y += ft.vy * dt;
        ft.vy *= 0.96;
      }

      if (screenShake > 0) {
        screenShake = Math.max(0, screenShake - dt);
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      const W = rect.width;
      const H = rect.height;
      ctx.clearRect(0, 0, W, H);

      const m = getLayoutMetrics(W, H);
      const shakeX = screenShake > 0 ? (Math.random() - 0.5) * screenShake * 16 : 0;
      const shakeY = screenShake > 0 ? (Math.random() - 0.5) * screenShake * 16 : 0;

      ctx.save();
      ctx.translate(shakeX, shakeY);

      ctx.save();
      ctx.beginPath();
      ctx.roundRect(m.boxX, m.boxY, m.boxW, m.boxH, 10);
      ctx.fillStyle = 'rgba(21, 21, 21, 0.784)';
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.14)';
      ctx.stroke();
      ctx.clip();

      highlightedIds.clear();
      if (hintGroup) {
        for (let i = 0; i < hintGroup.balls.length; i++) {
          highlightedIds.add(hintGroup.balls[i].id);
        }
      }

      if (hintGroup && hintGroup.edges.length > 0) {
        const pulse = 0.38 + 0.25 * Math.sin(now * 0.007);
        ctx.save();
        ctx.globalAlpha = pulse;
        ctx.strokeStyle = '#ffe850';
        ctx.lineWidth = Math.max(4, m.pxPerUnit * 0.12);
        ctx.lineCap = 'round';
        for (let i = 0; i < hintGroup.edges.length; i++) {
          const edge = hintGroup.edges[i];
          ctx.beginPath();
          ctx.moveTo(m.originX + edge.from.x * m.pxPerUnit, m.originY - edge.from.y * m.pxPerUnit);
          ctx.lineTo(m.originX + edge.to.x * m.pxPerUnit, m.originY - edge.to.y * m.pxPerUnit);
          ctx.stroke();
        }
        ctx.restore();
      }

      for (let i = 0; i < pit.balls.length; i++) {
        const b = pit.balls[i];
        const rPx = b.radius * m.pxPerUnit;
        const shakeOffX = b.shakeTimer > 0 ? Math.sin(now * 0.12) * b.shakeAmp * m.pxPerUnit : 0;
        const cx = m.originX + b.x * m.pxPerUnit + shakeOffX;
        const cy = m.originY - b.y * m.pxPerUnit;
        const isHighlighted = highlightedIds.has(b.id);
        const isBoosterTarget =
          (curBoost === 'hammer' && hoveredBallId === b.id) ||
          (curBoost === 'swap' && (swapFirstId === b.id || hoveredBallId === b.id));
        const isRecord = b.tier === maxTier && maxTier >= 6;

        if (isRecord && !isHighlighted && !isBoosterTarget && curAssets && curAssets.ringGreen) {
          const pulse = 1.0 + 0.03 * Math.sin(now * 0.005);
          const ringSize = rPx * 2.38 * pulse * b.scaleAnim;
          ctx.save();
          ctx.globalAlpha = 0.65;
          ctx.drawImage(
            curAssets.ringGreen,
            cx - ringSize * 0.5,
            cy - ringSize * 0.5,
            ringSize,
            ringSize
          );
          ctx.restore();
        }

        if (isHighlighted || isBoosterTarget) {
          const ringPulse = 1.04 + 0.06 * Math.sin(now * 0.01);
          const ringSize = rPx * 2.42 * ringPulse * b.scaleAnim;
          ctx.save();
          ctx.globalAlpha = isHighlighted
            ? 0.5 + 0.3 * Math.sin(now * 0.008)
            : 0.95;
          if (curAssets && curAssets.ringYellow) {
            ctx.drawImage(
              curAssets.ringYellow,
              cx - ringSize * 0.5,
              cy - ringSize * 0.5,
              ringSize,
              ringSize
            );
          } else {
            ctx.beginPath();
            ctx.arc(cx, cy, rPx * 1.12, 0, Math.PI * 2);
            ctx.strokeStyle = '#fde047';
            ctx.lineWidth = 4;
            ctx.stroke();
          }
          ctx.restore();
        }

        drawBallSpriteAndText(
          ctx,
          curAssets,
          b.tier,
          cx,
          cy,
          rPx,
          b.angle,
          b.scaleAnim
        );

        if (curBoost === 'swap' && swapFirstId === b.id && curAssets && curAssets.swapIcon) {
          const iconSz = rPx * 0.92;
          ctx.drawImage(
            curAssets.swapIcon,
            cx + rPx * 0.35 - iconSz * 0.5,
            cy - rPx * 0.55 - iconSz * 0.5,
            iconSz,
            iconSz
          );
        }
      }

      for (let i = 0; i < pit.mergingBalls.length; i++) {
        const mb = pit.mergingBalls[i];
        const rPx = mb.radius * m.pxPerUnit;
        const cx = m.originX + mb.x * m.pxPerUnit;
        const cy = m.originY - mb.y * m.pxPerUnit;
        drawBallSpriteAndText(ctx, curAssets, mb.tier, cx, cy, rPx, mb.angle, mb.scale);
      }

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        const t = p.life / p.maxLife;
        const px = m.originX + p.x * m.pxPerUnit;
        const py = m.originY - p.y * m.pxPerUnit;
        ctx.save();
        ctx.translate(px, py);
        ctx.rotate(p.rotation);
        if (p.kind === 'ripple') {
          const s = (0.6 + t * 2.2) * m.pxPerUnit;
          ctx.globalAlpha = (1 - t) * 0.75;
          if (curAssets && curAssets.fxRipple) {
            ctx.drawImage(curAssets.fxRipple, -s * 0.5, -s * 0.5, s, s);
          } else {
            ctx.beginPath();
            ctx.arc(0, 0, s * 0.45, 0, Math.PI * 2);
            ctx.strokeStyle = p.color;
            ctx.lineWidth = 3;
            ctx.stroke();
          }
        } else {
          const s = p.size * (1 - t * 0.4) * m.pxPerUnit;
          ctx.globalAlpha = 1 - t;
          if (curAssets && curAssets.fxStar) {
            ctx.drawImage(curAssets.fxStar, -s * 0.5, -s * 0.5, s, s);
          } else {
            ctx.fillStyle = '#fde047';
            ctx.fillRect(-s * 0.25, -s * 0.25, s * 0.5, s * 0.5);
          }
        }
        ctx.restore();
      }

      for (let i = 0; i < texts.length; i++) {
        const ft = texts[i];
        const t = ft.life / ft.maxLife;
        const alpha = t < 0.7 ? 1 : 1 - (t - 0.7) / 0.3;
        const fx = m.originX + ft.x * m.pxPerUnit;
        const fy = m.originY - ft.y * m.pxPerUnit;

        ctx.save();
        ctx.globalAlpha = Math.max(0, alpha);
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        const mainSz = Math.round(m.pxPerUnit * 0.38 * ft.scale);
        ctx.font = getBallFont(mainSz);
        ctx.lineJoin = 'round';
        ctx.lineWidth = 4;
        ctx.strokeStyle = GAME_CONFIG.ballNumberOutlineColor;

        if (ft.hasCoin && curAssets && curAssets.coinIcon) {
          const coinSz = Math.round(mainSz * 0.95);
          const textW = ctx.measureText(ft.text).width;
          const totalW = coinSz + 4 + textW;
          const startX = fx - totalW * 0.5;
          ctx.drawImage(curAssets.coinIcon, startX, fy - coinSz * 0.5, coinSz, coinSz);
          ctx.textAlign = 'left';
          ctx.strokeText(ft.text, startX + coinSz + 4, fy);
          ctx.fillStyle = '#ffffff';
          ctx.fillText(ft.text, startX + coinSz + 4, fy);
        } else {
          ctx.strokeText(ft.text, fx, fy);
          ctx.fillStyle = GAME_CONFIG.ballNumberFaceColor;
          ctx.fillText(ft.text, fx, fy);
        }
        ctx.restore();
      }

      ctx.restore();
      ctx.restore();
      ctx.restore();
    }

    rafId = requestAnimationFrame(loop);
  }

  canvas.addEventListener('pointermove', handlePointerMove);
  canvas.addEventListener('pointerleave', handlePointerLeave);
  canvas.addEventListener('pointerdown', handlePointerDown);
  rafId = requestAnimationFrame(loop);

  return {
    updateOptions(next) {
      if ('assets' in next) state.assets = next.assets;
      if ('spawnMinTier' in next && 'spawnMaxTier' in next) {
        state.spawnMinTier = next.spawnMinTier;
        state.spawnMaxTier = next.spawnMaxTier;
        pit.setSpawnRange(next.spawnMinTier, next.spawnMaxTier);
        if (pit.balls.length === 0) {
          pit.fillPitBalls(state.spawnMinTier, state.spawnMaxTier);
          callbacks.onBoardChanged(pit.serializeBalls());
        }
      }
      if ('curMaxTier' in next) state.curMaxTier = next.curMaxTier;
      if ('activeBoost' in next) {
        state.activeBoost = next.activeBoost;
        if (next.activeBoost !== 'swap') {
          swapFirstId = null;
        }
        canvas.className = next.activeBoost
          ? 'game-canvas is-targeting'
          : 'game-canvas';
      }
      if ('paused' in next) state.paused = next.paused;
    },
    resetBoard(minT, maxT) {
      state.spawnMinTier = minT;
      state.spawnMaxTier = maxT;
      pit.reset([]);
      pit.fillPitBalls(minT, maxT);
      particles.length = 0;
      texts.length = 0;
      completedMerges.length = 0;
      hoveredBallId = null;
      swapFirstId = null;
      hintGroup = null;
      idleTimer = 0;
      noMovesTriggered = false;
      stillFrames = 0;
      callbacks.onBoardChanged(pit.serializeBalls());
    },
    triggerShake() {
      gameAudio.play('shake');
      screenShake = 0.45;
      pit.applyRadialExplosion(
        0,
        0,
        GAME_CONFIG.shakeExplosionRadius,
        GAME_CONFIG.shakeExplosionForce
      );
      for (let i = 0; i < pit.balls.length; i++) {
        const b = pit.balls[i];
        b.shakeTimer = 0.45;
        b.shakeAmp = 0.05;
      }
      noMovesTriggered = false;
      stillFrames = 0;
      idleTimer = 0;
      hintGroup = null;
    },
    shiftSpawnRange(newMin, newMax) {
      const range = Math.max(1, newMax - newMin + 1);
      for (let i = 0; i < pit.balls.length; i++) {
        const b = pit.balls[i];
        if (!b.lockedForMerge && b.tier < newMin) {
          const upgraded = newMin + Math.floor(Math.random() * Math.min(2, range));
          pit.setBallTier(b.id, upgraded);
          b.scaleAnim = 0.5;
          spawnBurstParticles(b.x, b.y, getTierConfig(upgraded).color, 4, false);
        }
      }
      callbacks.onBoardChanged(pit.serializeBalls());
    },
    recheckMoves() {
      noMovesTriggered = false;
      stillFrames = 0;
    },
    destroy() {
      cancelAnimationFrame(rafId);
      canvas.removeEventListener('pointermove', handlePointerMove);
      canvas.removeEventListener('pointerleave', handlePointerLeave);
      canvas.removeEventListener('pointerdown', handlePointerDown);
    },
  };
}
