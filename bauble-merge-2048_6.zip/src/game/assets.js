import { BALL_TIERS } from './constants.js';

function loadImage(src) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function createGreenRingCanvas(ringImg) {
  const size = ringImg.width || 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  ctx.drawImage(ringImg, 0, 0, size, size);
  ctx.globalCompositeOperation = 'source-in';
  ctx.fillStyle = '#00ff3c';
  ctx.fillRect(0, 0, size, size);
  ctx.globalCompositeOperation = 'source-over';
  return canvas;
}

export async function preloadGameAssets() {
  const [ringYellow, fxStar, fxRipple, swapIcon, coinIcon] = await Promise.all([
    loadImage('./assets/sprites/ringyellow.png'),
    loadImage('./assets/textures/PP_FX_Star.png'),
    loadImage('./assets/textures/PP_Water_Ripple_01.png'),
    loadImage('./assets/sprites/Swap.png'),
    loadImage('./assets/sprites/Itemicon_Coin_Gold_Star.png'),
  ]);

  const rawBalls = new Map();

  await Promise.all(
    BALL_TIERS.map(async (tierCfg) => {
      const img = await loadImage(`./assets/sprites/${tierCfg.sprite}.png`);
      if (img) {
        rawBalls.set(tierCfg.tier, img);
      }
    })
  );

  return {
    ringYellow,
    ringGreen: ringYellow ? createGreenRingCanvas(ringYellow) : null,
    fxStar,
    fxRipple,
    swapIcon,
    coinIcon,
    rawBalls,
  };
}
