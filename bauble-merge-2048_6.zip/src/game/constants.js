export const BALL_TIERS = [
  { tier: 1, label: '2', sprite: 'Ball_2', shiftX: 0.0, shiftY: 0.085, scale: 1.675, color: '#de62c3' },
  { tier: 2, label: '4', sprite: 'Ball_4', shiftX: 0.0, shiftY: 0.085, scale: 1.675, color: '#87b84c' },
  { tier: 3, label: '8', sprite: 'Ball_8', shiftX: 0.0, shiftY: 0.085, scale: 1.675, color: '#45cac9' },
  { tier: 4, label: '16', sprite: 'Ball_16', shiftX: 0.0, shiftY: 0.085, scale: 1.675, color: '#6281e0' },
  { tier: 5, label: '32', sprite: 'Ball_32', shiftX: 0.0, shiftY: 0.085, scale: 1.675, color: '#e58956' },
  { tier: 6, label: '64', sprite: 'Ball_64', shiftX: 0.0, shiftY: 0.085, scale: 1.675, color: '#8c7cff' },
  { tier: 7, label: '128', sprite: 'Ball_128', shiftX: 0.005, shiftY: 0.01, scale: 1.59, color: '#8cb8ca' },
  { tier: 8, label: '256', sprite: 'Ball_256', shiftX: 0.005, shiftY: 0.01, scale: 1.59, color: '#fc5474' },
  { tier: 9, label: '512', sprite: 'Ball_512', shiftX: 0.005, shiftY: 0.01, scale: 1.59, color: '#02bd71' },
  { tier: 10, label: '1024', sprite: 'Ball_1024', shiftX: 0.005, shiftY: 0.01, scale: 1.59, color: '#849895' },
  { tier: 11, label: '2048', sprite: 'Ball_2048', shiftX: 0.0, shiftY: 0.12, scale: 1.75, color: '#ff8303' },
  { tier: 12, label: '4096', sprite: 'Ball_4096', shiftX: 0.0, shiftY: 0.12, scale: 1.75, color: '#b981d1' },
  { tier: 13, label: '8192', sprite: 'Ball_8192', shiftX: 0.0, shiftY: 0.185, scale: 1.85, color: '#75a8eb' },
  { tier: 14, label: '16k', sprite: 'Ball_16k', shiftX: 0.0, shiftY: 0.185, scale: 1.85, color: '#aba057' },
  { tier: 15, label: '32k', sprite: 'Ball_32k', shiftX: 0.0, shiftY: 0.185, scale: 1.85, color: '#fe730a' },
  { tier: 16, label: '64k', sprite: 'Ball_64k', shiftX: 0.0, shiftY: 0.092, scale: 1.7, color: '#de62c3' },
  { tier: 17, label: '128k', sprite: 'Ball_128k', shiftX: 0.0, shiftY: 0.15, scale: 1.79, color: '#87b84c' },
  { tier: 18, label: '256k', sprite: 'Ball_256k', shiftX: 0.0, shiftY: 0.12, scale: 1.74, color: '#45cac9' },
  { tier: 19, label: '512k', sprite: 'Ball_512k', shiftX: 0.0, shiftY: 0.14, scale: 1.77, color: '#6281e0' },
  { tier: 20, label: '1M', sprite: 'Ball_1M', shiftX: 0.0, shiftY: 0.12, scale: 1.74, color: '#e58956' },
  { tier: 21, label: '2M', sprite: 'Ball_2M', shiftX: 0.0, shiftY: 0.165, scale: 1.79, color: '#8c7cff' },
  { tier: 22, label: '4M', sprite: 'Ball_4M', shiftX: 0.09, shiftY: 0.0, scale: 1.7, color: '#8cb8ca' },
  { tier: 23, label: '8M', sprite: 'Ball_8M', shiftX: 0.0, shiftY: 0.09, scale: 1.72, color: '#fc5474' },
  { tier: 24, label: '16M', sprite: 'Ball_16M', shiftX: 0.0, shiftY: 0.1, scale: 1.65, color: '#02bd71' },
  { tier: 25, label: '32M', sprite: 'Ball_32M', shiftX: 0.0, shiftY: 0.11, scale: 1.715, color: '#849895' },
  { tier: 26, label: '64M', sprite: 'Ball_64M', shiftX: 0.0, shiftY: 0.11, scale: 1.74, color: '#ff8303' },
  { tier: 27, label: '128M', sprite: 'Ball_128M', shiftX: 0.0, shiftY: 0.1, scale: 1.68, color: '#b981d1' },
  { tier: 28, label: '256M', sprite: 'Ball_256M', shiftX: 0.0, shiftY: 0.125, scale: 1.755, color: '#75a8eb' },
  { tier: 29, label: '512M', sprite: 'Ball_512M', shiftX: 0.0, shiftY: 0.08, scale: 1.7, color: '#aba057' },
  { tier: 30, label: '1B', sprite: 'Ball_1B', shiftX: 0.0, shiftY: 0.12, scale: 1.71, color: '#fe730a' },
];

export function getTierConfig(tier) {
  const idx = Math.max(0, Math.min(BALL_TIERS.length - 1, tier - 1));
  return BALL_TIERS[idx];
}

export function getBallRadius(tier) {
  return GAME_CONFIG.baseBallRadius + Math.max(0, tier - 1) * GAME_CONFIG.ballRadiusStep;
}

export const GAME_CONFIG = {
  fieldWidth: 5.0,
  fieldHeight: 8.0,
  spawnTopHeight: 9.0,
  ballVisibilityHeight: 7.35,
  binsCount: 10,
  baseBallRadius: 0.41,
  ballRadiusStep: 0.01,
  baseBallMass: 1.0,
  massGrowPower: 3.0,
  gravity: 40.0,
  linearDamping: 0.1,
  angularDamping: 0.05,
  ballBounciness: 0.25,
  wallBounciness: 0.0,
  friction: 0.05,
  mergeTime: 0.4,
  newBallWaitTime: 0.5,
  maxMergeDistanceFactor: 0.83,
  comboMinSize: 6,
  comboMidSize: 9,
  comboHighSize: 12,
  spawnRangeSize: 6,
  firstSpawnRangeChangeTier: 11, // 2048 (0-indexed 10 in RulesSO)
  spawnRangeChangeStep: 2,
  firstGoalTier: 10, // 1024 (0-indexed 9 in RulesSO)
  newBallBaseReward: 20,
  newBallRewardStep: 10,
  boostSwapBasePrice: 50,
  boostSwapMult: 1.2,
  boostShakeBasePrice: 10,
  boostShakeMult: 1.25,
  boostHammerBasePrice: 50,
  boostHammerMult: 1.2,
  shakeExplosionRadius: 7.0,
  shakeExplosionForce: 35.0,
  hintDelaySec: 5.0,
  initialCoins: 0,
  initialSwapUses: 0,
  initialShakeUses: 0,
  initialHammerUses: 0,
  ballNumberFaceColor: '#faff42',
  ballNumberOutlineColor: '#00003f',
};

export function getBoostPrice(basePrice, mult, usesCount) {
  if (!usesCount || usesCount <= 0) return basePrice;
  return Math.floor((basePrice * Math.pow(mult, usesCount)) / 5 + 0.5) * 5;
}

export function calcScoreForMove(rootTier, count) {
  return rootTier * count + (count >= GAME_CONFIG.comboMinSize ? count : 0);
}

export function calcComboCoins(count) {
  if (count >= GAME_CONFIG.comboHighSize) return 20;
  if (count >= GAME_CONFIG.comboMidSize) return 10;
  if (count >= GAME_CONFIG.comboMinSize) return 5;
  return 0;
}

export function getPreGoalMilestoneReward(newTier) {
  if (newTier < 7 || newTier >= GAME_CONFIG.firstGoalTier) return 0;
  return (newTier - 6) * 5; // 128 -> +5, 256 -> +10, 512 -> +15
}

export function getNewBallReward(newTier, steps = 1) {
  if (steps <= 0) return 0;
  const newVal0 = newTier - 1;
  const firstGoal0 = GAME_CONFIG.firstGoalTier - 1;
  const arith = (((newVal0 - (firstGoal0 + steps)) * 2 + steps + 1) * steps) / 2;
  return GAME_CONFIG.newBallRewardStep * arith + GAME_CONFIG.newBallBaseReward * steps;
}

export const STORAGE_KEY = 'bauble_merge_2048_save_v2';
