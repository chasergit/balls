import { GAME_CONFIG, getTierConfig } from './constants.js';

export function renderBaublePreview(canvas, tier, assets, size = 56) {
  if (!canvas) return;
  const cfg = getTierConfig(tier);
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const pxW = Math.round(size * dpr);
  const pxH = Math.round(size * dpr);

  if (canvas.width !== pxW || canvas.height !== pxH) {
    canvas.width = pxW;
    canvas.height = pxH;
  }
  canvas.style.width = `${size}px`;
  canvas.style.height = `${size}px`;
  canvas.setAttribute('aria-label', `Шарик ${cfg.label}`);

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  ctx.save();
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, size, size);

  const cx = size * 0.5;
  const cy = size * 0.5;
  const rPx = size * 0.37;
  const rawImg = assets && assets.rawBalls ? assets.rawBalls.get(tier) : null;

  if (rawImg) {
    const spriteDrawSize = rPx * cfg.scale * 1.28;
    const offX = cfg.shiftX * rPx;
    const offY = -cfg.shiftY * rPx;
    ctx.drawImage(
      rawImg,
      cx - spriteDrawSize * 0.5 + offX,
      cy - spriteDrawSize * 0.5 + offY,
      spriteDrawSize,
      spriteDrawSize
    );
  } else {
    ctx.beginPath();
    ctx.arc(cx, cy, rPx, 0, Math.PI * 2);
    ctx.fillStyle = cfg.color;
    ctx.fill();
  }

  const label = cfg.label;
  const fontScale =
    label.length <= 1
      ? 0.96
      : label.length === 2
        ? 0.84
        : label.length === 3
          ? 0.68
          : 0.54;
  const fontSize = Math.max(9, Math.round(rPx * fontScale));
  ctx.font = `700 ${fontSize}px "Fredoka", "Plus Jakarta Sans", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  ctx.lineWidth = Math.max(2, fontSize * 0.17);
  ctx.strokeStyle = GAME_CONFIG.ballNumberOutlineColor;
  ctx.strokeText(label, cx, cy);
  ctx.fillStyle = GAME_CONFIG.ballNumberFaceColor;
  ctx.fillText(label, cx, cy);
  ctx.restore();
}

export function createBaublePreview(tier, assets, size = 56) {
  const canvas = document.createElement('canvas');
  canvas.className = 'bauble-preview';
  let curTier = tier;
  let curAssets = assets;
  let curSize = size;

  renderBaublePreview(canvas, curTier, curAssets, curSize);

  return {
    el: canvas,
    update(nextTier, nextAssets = curAssets, nextSize = curSize) {
      if (nextTier === curTier && nextAssets === curAssets && nextSize === curSize) return;
      curTier = nextTier;
      curAssets = nextAssets;
      curSize = nextSize;
      renderBaublePreview(canvas, curTier, curAssets, curSize);
    },
  };
}
