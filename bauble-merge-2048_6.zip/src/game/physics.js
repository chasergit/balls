import { GAME_CONFIG, getBallRadius } from './constants.js';

const SOLVER_SLOP = 0.0015;
const MAX_POS_CORRECTION = 0.2;
const VEL_THRESHOLD = 1.2;
const SLEEP_LINEAR_SQ = 0.06 * 0.06;
const SLEEP_ANGULAR = (12 / 180) * Math.PI;
const SLEEP_TIME = 0.3;
const MAX_CONTACTS = 512;

let nextEntityId = 1;
export function allocEntityId() {
  return nextEntityId++;
}

function computeTargetMass(radius) {
  return (
    GAME_CONFIG.baseBallMass *
    Math.pow(radius / GAME_CONFIG.baseBallRadius, GAME_CONFIG.massGrowPower)
  );
}

export class PhysicsPit {
  constructor(initialSaved = [], spawnMinTier = 1, spawnMaxTier = 6) {
    this.balls = [];
    this.ballById = new Map();
    this.mergingBalls = [];
    this.pendingMerges = [];
    this.spawnCooldown = 0;
    this.spawnMinTier = spawnMinTier;
    this.spawnMaxTier = spawnMaxTier;
    this.epoch = 0;
    this.accumulator = 0;
    this.anyAwake = false;

    // Preallocated buffers to avoid per-frame GC allocations
    this._binTops = new Float64Array(GAME_CONFIG.binsCount);
    this._candidates = Array.from({ length: GAME_CONFIG.binsCount }, () => ({ idx: 0, top: 0 }));
    this._contacts = Array.from({ length: MAX_CONTACTS }, () => ({
      aIdx: 0,
      bIdx: 0,
      nx: 0,
      ny: 0,
      pen: 0,
      velocityBias: 0,
      normalImpulse: 0,
      tangentImpulse: 0,
    }));
    this._contactCount = 0;

    if (initialSaved.length > 0) {
      this.restoreFromSaved(initialSaved);
    }
  }

  setSpawnRange(minTier, maxTier) {
    this.spawnMinTier = minTier;
    this.spawnMaxTier = maxTier;
  }

  reset(initialSaved = []) {
    this.epoch++;
    this.balls.length = 0;
    this.ballById.clear();
    this.mergingBalls.length = 0;
    this.pendingMerges.length = 0;
    this.spawnCooldown = 0;
    this.accumulator = 0;
    this.anyAwake = false;
    this._contactCount = 0;
    if (initialSaved.length > 0) {
      this.restoreFromSaved(initialSaved);
    }
  }

  restoreFromSaved(saved) {
    const halfW = GAME_CONFIG.fieldWidth * 0.5;
    for (let i = 0; i < saved.length; i++) {
      const s = saved[i];
      const r = getBallRadius(s.tier);
      const cx = Math.max(-halfW + r + 0.01, Math.min(halfW - r - 0.01, s.x));
      const cy = Math.max(r + 0.01, Math.min(14.0, s.y));
      const b = this.spawnBall(s.tier, cx, cy, s.angle ?? 0, 0, 0);
      b.scaleAnim = 1;
    }
  }

  serializeBalls() {
    const out = new Array(this.balls.length);
    for (let i = 0; i < this.balls.length; i++) {
      const b = this.balls[i];
      out[i] = {
        tier: b.tier,
        x: Math.round(b.x * 10000) / 10000,
        y: Math.round(b.y * 10000) / 10000,
        angle: Math.round(b.angle * 1000) / 1000,
      };
    }
    return out;
  }

  spawnBall(tier, x, y, angle = 0, vy = -0.8, scaleAnim = 0.35) {
    const id = allocEntityId();
    const radius = getBallRadius(tier);
    const mass = computeTargetMass(radius);
    const invMass = 1 / mass;
    const invInertia = 1 / (0.5 * mass * radius * radius);

    const entity = {
      id,
      tier,
      x,
      y,
      vx: 0,
      vy,
      angle,
      omega: (Math.random() - 0.5) * 0.35,
      radius,
      mass,
      invMass,
      invInertia,
      scaleAnim,
      shakeTimer: 0,
      shakeAmp: 0,
      lockedForMerge: false,
      sleeping: false,
      sleepTimer: 0,
    };

    this.ballById.set(id, entity);
    this.balls.push(entity);
    this.anyAwake = true;
    return entity;
  }

  wakeBall(b) {
    if (b.sleeping) {
      b.sleeping = false;
      b.sleepTimer = 0;
    }
    this.anyAwake = true;
  }

  wakeNearby(centerX, centerY, radius) {
    for (let i = 0; i < this.balls.length; i++) {
      const b = this.balls[i];
      if (!b.sleeping) continue;
      const dx = b.x - centerX;
      const dy = b.y - centerY;
      const reach = radius + b.radius;
      if (dx * dx + dy * dy <= reach * reach) {
        b.sleeping = false;
        b.sleepTimer = 0;
        this.anyAwake = true;
      }
    }
  }

  removeBall(id) {
    const target = this.ballById.get(id);
    if (target) {
      this.wakeNearby(target.x, target.y, target.radius + 1.5);
      this.ballById.delete(id);
    }
    const idx = this.balls.findIndex((b) => b.id === id);
    if (idx !== -1) {
      this.balls.splice(idx, 1);
      return true;
    }
    return false;
  }

  setBallTier(id, newTier) {
    const entity = this.ballById.get(id);
    if (!entity) return null;

    const newRadius = getBallRadius(newTier);
    const newMass = computeTargetMass(newRadius);

    entity.tier = newTier;
    entity.radius = newRadius;
    entity.mass = newMass;
    entity.invMass = 1 / newMass;
    entity.invInertia = 1 / (0.5 * newMass * newRadius * newRadius);

    const halfW = GAME_CONFIG.fieldWidth * 0.5;
    entity.x = Math.max(-halfW + newRadius + 0.005, Math.min(halfW - newRadius - 0.005, entity.x));
    entity.y = Math.max(newRadius + 0.005, entity.y);

    this.wakeBall(entity);
    this.wakeNearby(entity.x, entity.y, newRadius + 1.2);
    return entity;
  }

  swapBallTiers(idA, idB) {
    const a = this.ballById.get(idA);
    const b = this.ballById.get(idB);
    if (!a || !b || a.lockedForMerge || b.lockedForMerge) return false;

    const tierA = a.tier;
    const tierB = b.tier;
    this.setBallTier(a.id, tierB);
    this.setBallTier(b.id, tierA);
    a.scaleAnim = 0.55;
    b.scaleAnim = 0.55;
    a.shakeTimer = 0.25;
    a.shakeAmp = 0.035;
    b.shakeTimer = 0.25;
    b.shakeAmp = 0.035;
    return true;
  }

  startMerge(rootId, absorbedBalls, duration, mergeMeta) {
    const root = this.ballById.get(rootId);
    if (!root) return;
    root.lockedForMerge = true;

    for (let i = 0; i < absorbedBalls.length; i++) {
      const b = absorbedBalls[i];
      if (b.id === rootId) continue;
      this.mergingBalls.push({
        tier: b.tier,
        targetId: rootId,
        startX: b.x,
        startY: b.y,
        lastTargetX: root.x,
        lastTargetY: root.y,
        x: b.x,
        y: b.y,
        angle: b.angle,
        radius: b.radius,
        elapsed: 0,
        duration,
        scale: b.scaleAnim,
      });
      this.removeBall(b.id);
    }

    if (mergeMeta) {
      this.pendingMerges.push({
        rootId,
        oldTier: mergeMeta.oldTier,
        newTier: mergeMeta.newTier,
        count: mergeMeta.count,
        isCombo: mergeMeta.isCombo,
        isNewMax: mergeMeta.isNewMax,
        elapsed: 0,
        duration,
      });
    }
  }

  applyRadialExplosion(centerX, centerY, radius, force, excludeId) {
    if (force <= 0 || radius <= 0) return;
    const radiusSq = radius * radius;
    for (let i = 0; i < this.balls.length; i++) {
      const b = this.balls[i];
      if (b.id === excludeId) continue;

      const dx = b.x - centerX;
      const dy = b.y - centerY;
      const distSq = dx * dx + dy * dy;
      if (distSq <= 1e-8 || distSq >= radiusSq) continue;

      const dist = Math.sqrt(distSq);
      const falloff = Math.sqrt(1 - dist / radius);
      const impulseMag = falloff * force;
      const invDist = 1 / dist;

      this.wakeBall(b);
      b.vx += dx * invDist * impulseMag * b.invMass;
      b.vy += dy * invDist * impulseMag * b.invMass;
    }
  }

  hasOverlapAt(x, y, radius) {
    const pad = 0.04;
    for (let i = 0; i < this.balls.length; i++) {
      const b = this.balls[i];
      const dx = b.x - x;
      const dy = b.y - y;
      const minD = b.radius + radius + pad;
      if (dx * dx + dy * dy < minD * minD) {
        return true;
      }
    }
    return false;
  }

  computeBinTops() {
    const halfW = GAME_CONFIG.fieldWidth * 0.5;
    const bins = GAME_CONFIG.binsCount;
    const binW = GAME_CONFIG.fieldWidth / bins;
    const binTops = this._binTops;
    binTops.fill(0);

    for (let j = 0; j < this.balls.length; j++) {
      const b = this.balls[j];
      const leftBin = Math.max(0, Math.min(bins - 1, Math.floor((b.x - b.radius * 0.8 + halfW) / binW)));
      const rightBin = Math.max(0, Math.min(bins - 1, Math.floor((b.x + b.radius * 0.8 + halfW) / binW)));
      const topY = b.y + b.radius;
      for (let i = leftBin; i <= rightBin; i++) {
        if (topY > binTops[i]) {
          binTops[i] = topY;
        }
      }
    }
    return binTops;
  }

  fillPitBalls(spawnMinTier, spawnMaxTier) {
    this.spawnMinTier = spawnMinTier;
    this.spawnMaxTier = spawnMaxTier;
    const range = Math.max(1, spawnMaxTier - spawnMinTier + 1);
    const halfW = GAME_CONFIG.fieldWidth * 0.5;

    if (this.balls.length === 0) {
      const spawned = [];
      let y = 0.52;
      let row = 0;
      while (y < 7.65 && spawned.length < 56) {
        const offset = row % 2 === 0 ? 0.0 : 0.44;
        for (let xBase = -2.02 + offset * 0.5; xBase <= 2.02; xBase += 0.92) {
          const tier = spawnMinTier + Math.floor(Math.random() * range);
          const r = getBallRadius(tier);
          const x = Math.max(
            -halfW + r + 0.03,
            Math.min(halfW - r - 0.03, xBase + (Math.random() - 0.5) * 0.08)
          );
          const yPos = y + (Math.random() - 0.5) * 0.06;
          if (!this.hasOverlapAt(x, yPos, r)) {
            spawned.push(this.spawnBall(tier, x, yPos, 0, -0.3, 0.55));
          }
        }
        y += 0.84;
        row++;
      }
      return spawned;
    }

    return [];
  }

  processSpawnTick(dt) {
    if (this.mergingBalls.length > 0) return;
    this.spawnCooldown = Math.max(0, this.spawnCooldown - dt);
    if (this.spawnCooldown > 0) return;

    const halfW = GAME_CONFIG.fieldWidth * 0.5;
    const bins = GAME_CONFIG.binsCount;
    const binW = GAME_CONFIG.fieldWidth / bins;
    const binTops = this.computeBinTops();
    const range = Math.max(1, this.spawnMaxTier - this.spawnMinTier + 1);

    const candidates = this._candidates;
    let count = 0;
    for (let i = 0; i < bins; i++) {
      const top = binTops[i];
      if (top < GAME_CONFIG.ballVisibilityHeight) {
        let j = count;
        while (j > 0 && candidates[j - 1].top > top) {
          candidates[j].idx = candidates[j - 1].idx;
          candidates[j].top = candidates[j - 1].top;
          j--;
        }
        candidates[j].idx = i;
        candidates[j].top = top;
        count++;
      }
    }
    if (count === 0) return;

    let spawnedCount = 0;
    for (let i = 0; i < count && spawnedCount < 2; i++) {
      const tier = this.spawnMinTier + Math.floor(Math.random() * range);
      const r = getBallRadius(tier);
      const binCenter = -halfW + (candidates[i].idx + 0.5) * binW;
      const jitter = (Math.random() - 0.5) * (binW * 0.45);
      const x = Math.max(-halfW + r + 0.03, Math.min(halfW - r - 0.03, binCenter + jitter));
      const y = GAME_CONFIG.spawnTopHeight;

      if (!this.hasOverlapAt(x, y, r)) {
        this.spawnBall(tier, x, y, 0, -1.1, 0.45);
        spawnedCount++;
      }
    }

    if (spawnedCount > 0) {
      this.spawnCooldown = 0.055;
    }
  }

  _stepPhysicsSubstep(subDt) {
    const balls = this.balls;
    const n = balls.length;
    if (n === 0) {
      this.anyAwake = false;
      return;
    }

    const gravity = GAME_CONFIG.gravity;
    const linDamp = 1 / (1 + GAME_CONFIG.linearDamping * subDt);
    const angDamp = 1 / (1 + GAME_CONFIG.angularDamping * subDt);
    const mu = GAME_CONFIG.friction;
    const ballBounce = GAME_CONFIG.ballBounciness;
    const wallBounce = GAME_CONFIG.wallBounciness;
    const halfW = GAME_CONFIG.fieldWidth * 0.5;
    const ceilingY = 15.0;
    const invSubDt = 1 / subDt;

    // 1. Save previous position, apply gravity & damping, predict position
    for (let i = 0; i < n; i++) {
      const b = balls[i];
      b.prevX = b.x;
      b.prevY = b.y;
      if (b.sleeping) {
        b.preVx = 0;
        b.preVy = 0;
        continue;
      }
      b.vy -= gravity * subDt;
      b.vx *= linDamp;
      b.vy *= linDamp;
      b.omega *= angDamp;
      b.preVx = b.vx;
      b.preVy = b.vy;
      b.x += b.vx * subDt;
      b.y += b.vy * subDt;
      b.angle += b.omega * subDt;
    }

    // 2. Broadphase / contact pair collection (small margin catches sliding contacts)
    const contacts = this._contacts;
    let cCount = 0;
    const margin = 0.03;
    for (let i = 0; i < n; i++) {
      const a = balls[i];
      for (let j = i + 1; j < n; j++) {
        const b = balls[j];
        if (a.sleeping && b.sleeping) continue;

        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const rSum = a.radius + b.radius;
        const searchR = rSum + margin;
        const distSq = dx * dx + dy * dy;
        if (distSq >= searchR * searchR) continue;

        if (distSq < rSum * rSum) {
          const dist = distSq > 1e-10 ? Math.sqrt(distSq) : 0;
          const pen = rSum - dist;
          const nx = dist > 0 ? dx / dist : 0;
          const ny = dist > 0 ? dy / dist : 1;
          const vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
          if (a.sleeping && (pen > 0.02 || vn < -0.3)) {
            a.sleeping = false;
            a.sleepTimer = 0;
          } else if (b.sleeping && (pen > 0.02 || vn < -0.3)) {
            b.sleeping = false;
            b.sleepTimer = 0;
          }
        }

        if (cCount < MAX_CONTACTS) {
          const c = contacts[cCount++];
          c.aIdx = i;
          c.bIdx = j;
          c.nx = 0;
          c.ny = 1;
          c.pen = 0;
          c.normalImpulse = 0;
        }
      }
    }
    this._contactCount = cCount;

    // 3. Symmetric XPBD Position Constraints (exact static stack equilibrium)
    const POS_ITERS = 18;
    for (let iter = 0; iter < POS_ITERS; iter++) {
      const rev = (iter & 1) === 1;
      for (let stepIdx = 0; stepIdx < cCount; stepIdx++) {
        const k = rev ? cCount - 1 - stepIdx : stepIdx;
        const c = contacts[k];
        const a = balls[c.aIdx];
        const b = balls[c.bIdx];
        if (a.sleeping && b.sleeping) continue;

        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const rSum = a.radius + b.radius;
        const distSq = dx * dx + dy * dy;
        if (distSq >= rSum * rSum) continue;

        let nx;
        let ny;
        let dist;
        if (distSq > 1e-10) {
          dist = Math.sqrt(distSq);
          nx = dx / dist;
          ny = dy / dist;
        } else {
          dist = 0;
          nx = 0;
          ny = 1;
        }

        const pen = rSum - dist;
        const wA = a.sleeping ? 0 : a.invMass;
        const wB = b.sleeping ? 0 : b.invMass;
        const wSum = wA + wB;
        if (wSum <= 0) continue;

        const lambda = Math.min(MAX_POS_CORRECTION, pen) / wSum;
        if (!a.sleeping) {
          a.x -= nx * lambda * wA;
          a.y -= ny * lambda * wA;
        }
        if (!b.sleeping) {
          b.x += nx * lambda * wB;
          b.y += ny * lambda * wB;
        }

        c.nx = nx;
        c.ny = ny;
        c.pen = 1;
        c.normalImpulse += lambda;
      }

      // Container walls (floor, left, right, ceiling)
      for (let i = 0; i < n; i++) {
        const b = balls[i];
        if (b.sleeping) continue;
        const r = b.radius;
        if (b.x < -halfW + r) b.x = -halfW + r;
        else if (b.x > halfW - r) b.x = halfW - r;
        if (b.y < r) b.y = r;
        else if (b.y > ceilingY - r) b.y = ceilingY - r;
      }
    }

    // 4. Derive velocities from solved displacements (zero gravity leakage!)
    for (let i = 0; i < n; i++) {
      const b = balls[i];
      if (b.sleeping) continue;
      b.vx = (b.x - b.prevX) * invSubDt;
      b.vy = (b.y - b.prevY) * invSubDt;
    }

    // 5. Velocity pass: restitution (only above VEL_THRESHOLD) & tangential friction
    for (let k = 0; k < cCount; k++) {
      const c = contacts[k];
      if (c.pen === 0) continue;
      const a = balls[c.aIdx];
      const b = balls[c.bIdx];
      if (a.sleeping && b.sleeping) continue;

      const nx = c.nx;
      const ny = c.ny;
      const tx = -ny;
      const ty = nx;
      const wA = a.sleeping ? 0 : a.invMass;
      const wB = b.sleeping ? 0 : b.invMass;
      const wSum = wA + wB;
      if (wSum <= 0) continue;

      // Restitution above threshold
      const vnPre = (b.preVx - a.preVx) * nx + (b.preVy - a.preVy) * ny;
      if (-vnPre > VEL_THRESHOLD) {
        const vnCur = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
        const targetVn = -ballBounce * vnPre;
        const dVn = targetVn - vnCur;
        if (dVn > 0) {
          const jn = dVn / wSum;
          if (!a.sleeping) {
            a.vx -= nx * jn * wA;
            a.vy -= ny * jn * wA;
          }
          if (!b.sleeping) {
            b.vx += nx * jn * wB;
            b.vy += ny * jn * wB;
          }
        }
      }

      // Tangential friction & spin
      const vAx = a.vx + a.omega * a.radius * (-ny);
      const vAy = a.vy + a.omega * a.radius * nx;
      const vBx = b.vx - b.omega * b.radius * (-ny);
      const vBy = b.vy - b.omega * b.radius * nx;
      const vt = (vBx - vAx) * tx + (vBy - vAy) * ty;
      const kT =
        wSum +
        (a.sleeping ? 0 : a.radius * a.radius * a.invInertia) +
        (b.sleeping ? 0 : b.radius * b.radius * b.invInertia);
      if (kT > 0) {
        const maxJt = mu * (c.normalImpulse * invSubDt);
        const jt = Math.max(-maxJt, Math.min(maxJt, -vt / kT));
        if (!a.sleeping) {
          a.vx -= tx * jt * wA;
          a.vy -= ty * jt * wA;
          a.omega -= a.radius * jt * a.invInertia;
        }
        if (!b.sleeping) {
          b.vx += tx * jt * wB;
          b.vy += ty * jt * wB;
          b.omega -= b.radius * jt * b.invInertia;
        }
      }
    }

    // Wall restitution & friction
    for (let i = 0; i < n; i++) {
      const b = balls[i];
      if (b.sleeping) continue;
      const r = b.radius;
      if (b.y <= r + SOLVER_SLOP) {
        if (-b.preVy > VEL_THRESHOLD && wallBounce > 0) {
          b.vy = Math.max(b.vy, -wallBounce * b.preVy);
        }
        const vt = b.vx - b.omega * r;
        const jt = Math.max(-mu * Math.abs(gravity * subDt * b.mass), Math.min(mu * Math.abs(gravity * subDt * b.mass), -vt / (b.invMass + r * r * b.invInertia)));
        b.vx += jt * b.invMass;
        b.omega -= jt * r * b.invInertia;
      }
      if (b.x <= -halfW + r + SOLVER_SLOP && -b.preVx > VEL_THRESHOLD && wallBounce > 0) {
        b.vx = Math.max(b.vx, -wallBounce * b.preVx);
      } else if (b.x >= halfW - r - SOLVER_SLOP && b.preVx > VEL_THRESHOLD && wallBounce > 0) {
        b.vx = Math.min(b.vx, -wallBounce * b.preVx);
      }
    }

    // 6. Sleep detection
    let awakeFlag = false;
    for (let i = 0; i < n; i++) {
      const b = balls[i];
      if (b.sleeping) continue;
      const vSq = b.vx * b.vx + b.vy * b.vy;
      if (vSq < SLEEP_LINEAR_SQ && Math.abs(b.omega) < SLEEP_ANGULAR) {
        b.sleepTimer += subDt;
        if (b.sleepTimer >= SLEEP_TIME) {
          b.sleeping = true;
          b.vx = 0;
          b.vy = 0;
          b.omega = 0;
          continue;
        }
      } else {
        b.sleepTimer = 0;
      }
      awakeFlag = true;
    }
    this.anyAwake = awakeFlag;
  }

  step(dt, completedMergesOut) {
    const clampedDt = Math.min(dt, 0.05);
    const FIXED_DT = 1 / 60;
    const SUB_DT = FIXED_DT * 0.5;

    this.processSpawnTick(clampedDt);

    for (let i = 0; i < this.balls.length; i++) {
      const b = this.balls[i];
      if (b.scaleAnim < 1) {
        b.scaleAnim = Math.min(1, b.scaleAnim + clampedDt * 5.8);
      }
      if (b.shakeTimer > 0) {
        b.shakeTimer = Math.max(0, b.shakeTimer - clampedDt);
      }
    }

    this.accumulator += clampedDt;
    let steps = 0;
    while (this.accumulator >= FIXED_DT && steps < 4) {
      this._stepPhysicsSubstep(SUB_DT);
      this._stepPhysicsSubstep(SUB_DT);
      this.accumulator -= FIXED_DT;
      steps++;
    }

    for (let i = 0; i < this.mergingBalls.length; i++) {
      const mb = this.mergingBalls[i];
      const target = this.ballById.get(mb.targetId);
      if (target) {
        mb.lastTargetX = target.x;
        mb.lastTargetY = target.y;
      }
      mb.elapsed = Math.min(mb.duration, mb.elapsed + clampedDt);
      const t = mb.elapsed / Math.max(0.001, mb.duration);
      const ease = t * t * (3 - 2 * t);
      mb.x = mb.startX + (mb.lastTargetX - mb.startX) * ease;
      mb.y = mb.startY + (mb.lastTargetY - mb.startY) * ease;
      mb.scale = Math.max(0.22, 1 - ease * 0.68);
    }

    // Advance deterministic pending merges (pause-safe & zero-timer)
    for (let i = this.pendingMerges.length - 1; i >= 0; i--) {
      const pm = this.pendingMerges[i];
      pm.elapsed += clampedDt;
      if (pm.elapsed >= pm.duration) {
        for (let j = this.mergingBalls.length - 1; j >= 0; j--) {
          if (this.mergingBalls[j].targetId === pm.rootId) {
            this.mergingBalls[j] = this.mergingBalls[this.mergingBalls.length - 1];
            this.mergingBalls.pop();
          }
        }
        this.pendingMerges.splice(i, 1);
        if (completedMergesOut) {
          completedMergesOut.push(pm);
        }
      }
    }
  }

  isSettled() {
    if (this.mergingBalls.length > 0 || this.pendingMerges.length > 0) return false;
    const binTops = this.computeBinTops();
    for (let i = 0; i < binTops.length; i++) {
      if (binTops[i] < GAME_CONFIG.ballVisibilityHeight) return false;
    }
    for (let i = 0; i < this.balls.length; i++) {
      const b = this.balls[i];
      if (b.lockedForMerge) return false;
      if (b.y > GAME_CONFIG.fieldHeight + 0.6) return false;
      if (b.vx * b.vx + b.vy * b.vy > 0.04) return false;
    }
    return true;
  }
}

function segmentIntersectsCircle(ax, ay, bx, by, cx, cy, r) {
  const dx = bx - ax;
  const dy = by - ay;
  const lenSq = dx * dx + dy * dy;
  if (lenSq < 1e-6) return false;
  let t = ((cx - ax) * dx + (cy - ay) * dy) / lenSq;
  if (t < 0) t = 0;
  else if (t > 1) t = 1;
  const px = ax + t * dx;
  const py = ay + t * dy;
  const ox = cx - px;
  const oy = cy - py;
  return ox * ox + oy * oy < r * r;
}

export function buildMergeTree(allBalls, rootId) {
  let root = null;
  for (let i = 0; i < allBalls.length; i++) {
    const b = allBalls[i];
    if (!b.lockedForMerge && b.id === rootId) {
      root = b;
      break;
    }
  }
  if (!root) return null;

  const maxGap = GAME_CONFIG.baseBallRadius * GAME_CONFIG.maxMergeDistanceFactor;
  const visited = new Set([root.id]);
  const queue = [root];
  const edges = [];
  let head = 0;

  while (head < queue.length) {
    const a = queue[head++];

    for (let i = 0; i < allBalls.length; i++) {
      const b = allBalls[i];
      if (b.lockedForMerge || b.tier !== root.tier || visited.has(b.id)) continue;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const limit = a.radius + b.radius + maxGap;
      if (dx * dx + dy * dy > limit * limit) continue;

      let blocked = false;
      for (let j = 0; j < allBalls.length; j++) {
        const other = allBalls[j];
        if (
          other.lockedForMerge ||
          other.id === a.id ||
          other.id === b.id ||
          other.tier === root.tier
        ) {
          continue;
        }
        if (segmentIntersectsCircle(a.x, a.y, b.x, b.y, other.x, other.y, other.radius * 0.85)) {
          blocked = true;
          break;
        }
      }
      if (blocked) continue;

      visited.add(b.id);
      edges.push({ from: b, to: a });
      queue.push(b);
    }
  }

  return { root, balls: queue, edges };
}

export function findLargestAvailableMerge(allBalls) {
  const checked = new Set();
  let best = null;

  for (let i = 0; i < allBalls.length; i++) {
    const b = allBalls[i];
    if (b.lockedForMerge || checked.has(b.id)) continue;
    const tree = buildMergeTree(allBalls, b.id);
    if (!tree) continue;
    for (let j = 0; j < tree.balls.length; j++) {
      checked.add(tree.balls[j].id);
    }
    if (tree.balls.length >= 2) {
      if (!best || tree.balls.length > best.balls.length) {
        best = tree;
      }
    }
  }
  return best;
}
